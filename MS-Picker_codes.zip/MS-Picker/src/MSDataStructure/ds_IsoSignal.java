package MSDataStructure;

import jdk.dynalink.linker.ConversionComparator;

import java.util.*;
public class ds_IsoSignal
{
    public ds_IsoSignal() {
    }

    private double mz;
    public final double getMz()
    {
        return mz;
    }
    public final void setMz(double value)
    {
        mz = value;
    }
    private double height;
    public final double getHeight()
    {
        return height;
    }
    public final void setHeight(double value)
    {
        height = value;
    }
}