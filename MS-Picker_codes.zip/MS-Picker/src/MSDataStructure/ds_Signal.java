package MSDataStructure;

import MSDataStructure.ds_IsoPeak;
import java.util.Comparator;
import java.util.Hashtable;

public class ds_Signal implements java.lang.Comparable<ds_Signal>
{
    public static class MZComparison implements Comparator{
        @Override
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };//public static ConversionComparator.Comparison MZComparison;<ds_Signal>

    public ds_Signal() {

    }

    private double mz;
    public final double getMz()
    {
        return mz;
    }
    public final void setMz(double value)
    {
        mz = value;
    }
    private double height;
    public final double getHeight()
    {
        return height;
    }
    public final void setHeight(double value)
    {
        height = value;
    }
    private boolean isProcessed;
    public final boolean isProcessed()
    {
        return isProcessed;
    }
    public final void setProcessed(boolean value)
    {
        isProcessed = value;
    }
    private Hashtable backIsoHT;
    public final Hashtable getBackIsoHT()
    {
        return backIsoHT;
    }
    public final void setBackIsoHT(Hashtable value)
    {
        backIsoHT = value;
    }
    private Hashtable frontIsoHT;
    public final Hashtable getFrontIsoHT()
    {
        return frontIsoHT;
    }
    public final void setFrontIsoHT(Hashtable value)
    {
        frontIsoHT = value;
    }
    @Override
    public int compareTo(ds_Signal s) {
        return 0;
    }
}