package MSDataStructure;

//import MSDataStructure.ds_Peak;
import java.util.ArrayList;

public class MSPoints
{
    public MSPoints(){};

    public ArrayList<Double> mzList ;
    public final ArrayList<Double> getMzList()
    {
        return mzList;
    }
    public final void setMzList(double value)
    {
        mzList.add(value);
    }
    public final void setMzListAll(ArrayList<Double> value)
    {
        mzList.addAll(value);
    }
    public ArrayList<Float> heightList;
    public final ArrayList<Float> getHeightList()
    {
        return heightList;
    }
    public final void setHeightList(float value)
    {
        heightList.add(value);
    }
    public final void setHeightListAll(ArrayList<Float> value)
    {
        heightList.addAll(value);
    }
    public ArrayList<Float> areaList;
    public final ArrayList<Float> getAreaList()
    {
        return areaList;
    }
    public final void setAreaList(Float value)
    {
        areaList.add(value);
    }
    public final void setAreaListAll(ArrayList<Float> value)
    {
        areaList.addAll(value);
    }
    public ArrayList<Float> noiseList;
    public final ArrayList<Float> getNoiseList()
    {
        return noiseList;
    }
    public final void setNoiseList(Float value)
    {
        noiseList.add(value);
    }
    public final void setNoiseListAll(ArrayList<Float> value)
    {
        noiseList.addAll(value);
    }
    public ArrayList<ds_Peak> plist;
    public final ArrayList<ds_Peak> getPlist()
    {
        return plist;
    }
    public final void setPlist(ds_Peak value)
    {
        plist.add(value);
    }
}