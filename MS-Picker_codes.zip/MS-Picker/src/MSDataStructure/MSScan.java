package MSDataStructure;

import MSDataStructure.MSPoints;

public class MSScan
{
    public MSScan(){};

    private float PrecursorIntensity;
    public final float getPrecursorIntensity()
    {
        return PrecursorIntensity;
    }
    public final void setPrecursorIntensity(float value)
    {
        PrecursorIntensity = value;
    }
    private double PrecursorMZ;
    public final double getPrecursorMZ()
    {
        return PrecursorMZ;
    }
    public final void setPrecursorMZ(double value)
    {
        PrecursorMZ = value;
    }
    private int PrecursorScanNum;
    public final int getPrecursorScanNum()
    {
        return PrecursorScanNum;
    }
    public final void setPrecursorScanNum(int value)
    {
        PrecursorScanNum = value;
    }
    private double NoiseLevel;
    public final double getNoiseLevel()
    {
        return NoiseLevel;
    }
    public final void setNoiseLevel(double value)
    {
        NoiseLevel = value;
    }
    private String ScanType;
    public final String getScanType()
    {
        return ScanType;
    }
    public final void setScanType(String value)
    {
        ScanType = value;
    }
    private double HighMZ;
    public final double getHighMZ()
    {
        return HighMZ;
    }
    public final void setHighMZ(double value)
    {
        HighMZ = value;
    }
    private double LowMZ;
    public final double getLowMZ()
    {
        return LowMZ;
    }
    public final void setLowMZ(double value)
    {
        LowMZ = value;
    }
    private String ActivationMethod;
    public final String getActivationMethod()
    {
        return ActivationMethod;
    }
    public final void setActivationMethod(String value)
    {
        ActivationMethod = value;
    }
    private float TotalIonCurrent;
    public final float getTotalIonCurrent()
    {
        return TotalIonCurrent;
    }
    public final void setTotalIonCurrent(float value)
    {
        TotalIonCurrent = value;
    }
    private double BasePeakIntensity;
    public final double getBasePeakIntensity()
    {
        return BasePeakIntensity;
    }
    public final void setBasePeakIntensity(double value)
    {
        BasePeakIntensity = value;
    }
    private double BasePeakMZ;
    public final double getBasePeakMZ()
    {
        return BasePeakMZ;
    }
    public final void setBasePeakMZ(double value)
    {
        BasePeakMZ = value;
    }
    public float RetentionTime;
    public final float getRetentionTime()
    {
        return RetentionTime;
    }
    public final void setRetentionTime(float value)
    {
        RetentionTime = value;
    }
    public int MsLevel;
    public final int getMsLevel()
    {
        return MsLevel;
    }
    public final void setMsLevel(int value)
    {
        MsLevel = value;
    }
    private int OriginalNum;
    public final int getOriginalNum()
    {
        return OriginalNum;
    }
    public final void setOriginalNum(int value)
    {
        OriginalNum = value;
    }
    private int Num;
    public final int getNum()
    {
        return Num;
    }
    public final void setNum(int value)
    {
        Num = value;
    }
    private float PrecursorCharge;
    public final float getPrecursorCharge()
    {
        return PrecursorCharge;
    }
    public final void setPrecursorCharge(float value)
    {
        PrecursorCharge = value;
    }
    public MSPoints Points;
    public final MSPoints getPoints()
    {
        return Points;
    }
    public final void setPoints(MSPoints value)
    {
        Points = value;
    }
}