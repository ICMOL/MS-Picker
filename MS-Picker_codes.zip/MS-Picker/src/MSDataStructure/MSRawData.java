package MSDataStructure;

import MSDataStructure.MSScan;

import java.util.ArrayList;
import java.util.HashMap;

public class MSRawData
{
    public MSRawData(){};

    private String FileName;
    public final String getFileName()
    {
        return FileName;
    }
    public final void setFileName(String value)
    {
        FileName = value;
    }
    public int NumScanLevel1;
    public final int getNumScanLevel1()
    {
        return NumScanLevel1;
    }
    public final void setNumScanLevel1(int value)
    {
        NumScanLevel1 = value;
    }
    public int NumScanLevel2;
    public final int getNumScanLevel2()
    {
        return NumScanLevel2;
    }
    public final void setNumScanLevel2(int value)
    {
        NumScanLevel2 = value;
    }
    private int MaxCycleNum;
    public final int getMaxCycleNum()
    {
        return MaxCycleNum;
    }
    public final void setMaxCycleNum(int value)
    {
        MaxCycleNum = value;
    }
    public double GlobalLowMZ;
    public final double getGlobalLowMZ()
    {
        return GlobalLowMZ;
    }
    public final void setGlobalLowMZ(double value)
    {
        GlobalLowMZ = value;
    }
    public double GlobalHighMZ;
    public final double getGlobalHighMZ()
    {
        return GlobalHighMZ;
    }
    public final void setGlobalHighMZ(double value)
    {
        GlobalHighMZ = value;
    }
    public HashMap<Integer, MSScan> ScanDic;
    public final HashMap<Integer, MSScan> getScanDic()
    {
        return ScanDic;
    }
    public final void setScanDic(Integer n, MSScan value)
    {
        ScanDic.put(n,value);
    }
    public ArrayList<Integer> ScanNumList;
    public final ArrayList<Integer> getScanNumList()
    {
        return ScanNumList;
    }
    public final void setScanNumList(Integer value)
    {
        ScanNumList.add(value);
    }
    public HashMap<Integer, ArrayList<Integer>> rtDi;
    public final HashMap<Integer, ArrayList<Integer>> getRtDi()
    {
        return rtDi;
    }
    public final void setRtDi(HashMap<Integer, ArrayList<Integer>> value)
    {
        rtDi = value;
    }

    public void Dispose() {
    }
}