package MSDataStructure;

import MSDataStructure.ds_IsoPeak;
import java.lang.Comparable;
import java.util.Comparator;
import java.util.Hashtable;

public class ds_Peak implements Comparable<MSDataStructure.ds_Peak>
{
    public static class MZComparison implements Comparator {
        @Override
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };
    public static class RTComparison implements Comparator{
        @Override
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };
    public static class ScanComparison implements Comparator{
        @Override
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };//<ds_Peak>

    public ds_Peak(){}

    private double mz;
    public final double getMz()
    {
        return mz;
    }
    public final void setMz(double value)
    {
        mz = value;
    }
    private float rt;
    public final float getRt()
    {
        return rt;
    }
    public final void setRt(float value)
    {
        rt = value;
    }
    private double height;
    public final double getHeight()
    {
        return height;
    }
    public final void setHeight(double value)
    {
        height = value;
    }
    private int scanNum;
    public final int getScanNum()
    {
        return scanNum;
    }
    public final void setScanNum(int value)
    {
        scanNum = value;
    }
    private double SN;
    public final double getSN()
    {
        return SN;
    }
    public final void setSN(double value)
    {
        SN = value;
    }
    private ds_IsoPeak monoIsop;
    public final ds_IsoPeak getMonoIsop()
    {
        return monoIsop;
    }
    public final void setMonoIsop(ds_IsoPeak value)
    {
        monoIsop = value;
    }
    private Hashtable isopHT;
    public final Hashtable getIsopHT()
    {
        return isopHT;
    }
    public final void setIsopHT(Hashtable value)
    {
        isopHT = value;
    }

    //public int CompareTo(ds_Peak p);

    @Override
    public int compareTo(MSDataStructure.ds_Peak p) {
        return 0;
    }
}