import peakdetection.pdStart;

import java.io.File;


// command: mzTol output_folder input_files
public class main {
    public static void main(String[] args) {
        int min = 60*1000;

        //Set up parameters
        float mzWidth = Float.parseFloat(args[0]) > 0? Float.parseFloat(args[0]): 0.03f;
        float NoiseLevel_inSpectrum = -1;
        float NoiseFactor = 3;
        int SegNum = 10;
        float minRT = 0;
        float maxRT = 999;
        int MinIons = 3;
        float Similarity = 0.8f;


        //By folder
        File folder = new File(args[2]);
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".mzml"));

        pdStart p = new pdStart();
        for (int i = 0; i < files.length; i++) {
            long startTime=System.currentTimeMillis();

            File input = files[i];
            String output = args[1] + "\\" + input.getName().substring(0,input.getName().lastIndexOf("."));
            p.process(input.getAbsolutePath().toString(), output,
                    /*in a spectrum*/
                    NoiseLevel_inSpectrum, NoiseFactor, SegNum, minRT * 60, maxRT * 60,
                    /*across spectra*/
                    mzWidth, MinIons, Similarity);

            long endTime = System.currentTimeMillis();
            System.out.println(input.getAbsolutePath().toString()+" running time: "+(endTime-startTime)/min+" min");
        }

        //Run peak detection; by single file
//        pdStart p = new pdStart();
//        for (int i = 2; i < args.length; i++) {
//            long startTime=System.currentTimeMillis();
//
//            File input = new File(args[i]);
//            String output = args[1] + "\\" + input.getName().substring(0,input.getName().lastIndexOf("."));
//            p.process(args[i], output,
//                    /*in a spectrum*/
//                    NoiseLevel_inSpectrum, NoiseFactor, SegNum, minRT * 60, maxRT * 60,
//                    /*across spectra*/
//                    mzWidth, MinIons, Similarity);
//
//            long endTime = System.currentTimeMillis();
//            System.out.println(args[i]+" running time: "+(endTime-startTime)/min+" min");
//        }

        System.out.println("Finish!");
    }
}
