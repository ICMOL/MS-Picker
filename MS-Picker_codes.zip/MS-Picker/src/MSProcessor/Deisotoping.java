package MSProcessor;

import MSDataStructure.*;
import java.util.*;

public class Deisotoping
{
	public final MSScan deFullScan(MSScan CentroidedScan, double MZWidth, int MinCharge, int MaxCharge)
	{
		ArrayList<ds_Peak> plist = new ArrayList<ds_Peak>();
		double searchRange = 1.003f + MZWidth * 1.5;
		float SN = 2;

		ArrayList<ds_Signal> slist = new ArrayList<ds_Signal>();
		//DataStructure Conversion
		for (int i = 0; i < CentroidedScan.Points.mzList.size(); i++)
		{
			ds_Signal s = new ds_Signal();
			s.setMz(CentroidedScan.Points.mzList.get(i));
			s.setHeight(CentroidedScan.Points.heightList.get(i));
			slist.add(s);
		}

		//Isotope Relation Construction
		for (int i = slist.size() - 1; i >= 0; i--)
		{
			if (slist.get(i) != null)
			{
				for (int j = i - 1; j >= 0; j--)
				{
					double mzdif = Math.abs(slist.get(i).getMz() - slist.get(j).getMz());
					if (mzdif <= MZWidth)
					{
						if (slist.get(i).getHeight()>= slist.get(j).getHeight())
						{
							slist.set(j, null);
						}
						else
						{
							slist.set(i, null);
							break;
						}
					}
					else if ((mzdif > MZWidth) && (mzdif <= searchRange))
					{
						int charge = Integer.parseInt(String.valueOf(1.0 / mzdif));
						if ((charge >= MinCharge) && (charge <= MaxCharge))
						{
							double upmz = slist.get(j).getMz() + (1.0f / ((double)charge)) + MZWidth * 1.5;
							double downmz = slist.get(j).getMz() + (1.0f / ((double)charge)) - MZWidth * 1.5;

							if ((slist.get(i).getMz() <= upmz) && (slist.get(i).getMz() >= downmz))
							{
								//backIsoHT
								if (slist.get(j).getBackIsoHT().containsKey(charge))
								{
									ds_Signal s = (ds_Signal)slist.get(j).getBackIsoHT().get(charge);
									if (s.getHeight() < slist.get(i).getHeight())
									{
										slist.get(j).getBackIsoHT().remove(charge);
										slist.get(j).getBackIsoHT().put(charge, slist.get(i));
									}
								}
								else
								{
									slist.get(j).getBackIsoHT().put(charge, slist.get(i));
								}

								//frontIsoHT
								if (slist.get(i).getFrontIsoHT().containsKey(charge))
								{
									ds_Signal s = (ds_Signal)slist.get(i).getFrontIsoHT().get(charge);
									if (s.getHeight() < slist.get(j).getHeight())
									{
										slist.get(i).getFrontIsoHT().remove(charge);
										slist.get(i).getFrontIsoHT().put(charge, slist.get(j));
									}
								}
								else
								{
									slist.get(i).getFrontIsoHT().put(charge, slist.get(j));
								}
							}
						}
					}
					else
					{
						break;
					}
				}
			}
		}

		//Remove peaks with no isotope peak
		ArrayList<ds_Signal> conSlist = new ArrayList<ds_Signal>();
		for (int i = 0; i < slist.size(); i++)
		{
			if (slist.get(i) != null)
			{
				conSlist.add(slist.get(i));
			}
		}
		slist.clear();

		//Find Isotope Envolope
		Collections.sort(conSlist); //Sort by Intensity
		double IntThreshold = CentroidedScan.getNoiseLevel() * SN;
		for (int i = conSlist.size() - 1; i >= 0; i--)
		{
			if ((!conSlist.get(i).isProcessed()) && (conSlist.get(i).getHeight() > IntThreshold))
			{
				ds_Peak p = new ds_Peak();
				p.setMz(conSlist.get(i).getMz());
				p.setRt(CentroidedScan.RetentionTime);
				p.setHeight(conSlist.get(i).getHeight());
				p.setScanNum(CentroidedScan.getNum());
				if (CentroidedScan.getNoiseLevel() > 0)
				{
					p.setSN(p.getHeight() / CentroidedScan.getNoiseLevel());
				}

				ArrayList ckey = new ArrayList(conSlist.get(i).getBackIsoHT().keySet());
				Collections.sort(ckey);

				for (int j = ckey.size() - 1; j >= 0; j--)
				{
					ArrayList<ds_Signal> isolist = new ArrayList<ds_Signal>();
					isolist.add(conSlist.get(i));

					ds_Signal bisoS = conSlist.get(i);
					double tempInt = bisoS.getHeight();
					while (bisoS != null)
					{
						if (bisoS.getBackIsoHT().containsKey(ckey.get(j)))
						{
							bisoS = (ds_Signal)bisoS.getBackIsoHT().get(ckey.get(j));
							if ((bisoS.getHeight() <= tempInt) && (!bisoS.isProcessed()))
							{
								isolist.add(bisoS);
								tempInt = bisoS.getHeight();
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}

					ds_Signal fisoS = conSlist.get(i);
					tempInt = fisoS.getHeight();
					while (fisoS != null)
					{
						if (fisoS.getFrontIsoHT().containsKey(ckey.get(j)))
						{
							fisoS = (ds_Signal)fisoS.getFrontIsoHT().get(ckey.get(j));
							if ((fisoS.getHeight() <= tempInt) && (!fisoS.isProcessed()))
							{
								isolist.add(fisoS);
								tempInt = fisoS.getHeight();
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}

					Collections.sort(isolist, new ds_Signal.MZComparison());
					int index = isolist.indexOf(conSlist.get(i));
					if (index < (isolist.size() - 1)) //the highest peak is not the last one
					{
						ArrayList<ds_IsoPeak> isoplist = new ArrayList<ds_IsoPeak>();
						for (int k = index + 1; k < isolist.size(); k++)
						{
							ds_IsoPeak isop = new ds_IsoPeak();
							isop.setMz(isolist.get(k).getMz());
							isop.setHeight(isolist.get(k).getHeight());
							isoplist.add(isop);
							isolist.get(k).setProcessed(true) ;
						}
						p.getIsopHT().put(ckey.get(j), isoplist);
					}
					else
					{
						if (conSlist.get(i).getBackIsoHT().containsKey(ckey.get(j)))
						{
							ds_Signal biso = (ds_Signal)conSlist.get(i).getBackIsoHT().get(ckey.get(j));

							if ((biso.getHeight() > conSlist.get(i).getHeight()) && (!biso.isProcessed()) && (biso.getBackIsoHT().containsKey(ckey.get(j))))
							{
								ds_IsoPeak isop = new ds_IsoPeak();
								isop.setMz(biso.getMz());
								isop.setHeight(biso.getHeight());

								ArrayList<ds_IsoPeak> isoplist = new ArrayList<ds_IsoPeak>();
								isoplist.add(isop);
								p.getIsopHT().put(ckey.get(j), isoplist);
								biso.setProcessed(true);
							}
						}
					}
				}
				plist.add(p);
			}
		}

		Collections.sort(plist, new ds_Peak.MZComparison());
		CentroidedScan.Points.mzList.clear();
		CentroidedScan.Points.heightList.clear();
		CentroidedScan.Points.areaList.clear();
		CentroidedScan.Points.getPlist().addAll(plist);

		return CentroidedScan;
	}

	public final HashMap<Integer, ArrayList<ds_Peak>> deFullScan(MSRawData raw, double MZWidth) //specially designed for Top-down protoemics
	{
		HashMap<Integer, ArrayList<ds_Peak>> deIsopDic = new HashMap<Integer, ArrayList<ds_Peak>>(); // for return, key :scan.Num, value: plist

		for (MSScan scan : raw.ScanDic.values())
		{
			ArrayList<ds_Signal> slist = new ArrayList<ds_Signal>();
			//DataStructure Conversion
			for (int i = 0; i < scan.Points.mzList.size(); i++)
			{
				ds_Signal s = new ds_Signal();
				s.setMz(scan.Points.mzList.get(i));
				s.setHeight(scan.Points.heightList.get(i));
				slist.add(s);
			}

			//Isotope Relation Construction
			double searchRange = 1.003f + MZWidth * 1.5;
			for (int i = slist.size() - 1; i >= 0; i--)
			{
				if (slist.get(i) != null)
				{
					for (int j = i - 1; j >= 0; j--)
					{
						double mzdif = Math.abs(slist.get(i).getMz() - slist.get(j).getMz());
						if (mzdif <= MZWidth)
						{
							if (slist.get(i).getHeight() >= slist.get(j).getHeight())
							{
								slist.set(j, null);
							}
							else
							{
								slist.set(i, null);
								break;
							}
						}
						else if ((mzdif > MZWidth) && (mzdif <= searchRange))
						{
							// mzWidth=0.02之下，search range是 1.006, 在這個範圍內可能會有幾十個 signal
							int charge = Integer.parseInt(String.valueOf(1.0 / mzdif)); //計算charge//FloatingPointToInteger.ToInt32
							double upmz = slist.get(j).getMz() + (1.0 / ((double)charge)) + MZWidth * 1.5;
							double downmz = slist.get(j).getMz() + (1.0 / ((double)charge)) - MZWidth * 1.5;

							if ((slist.get(i).getMz() <= upmz) && (slist.get(i).getMz() >= downmz))
							{
								//backIsoHT
								if (slist.get(j).getBackIsoHT().containsKey(charge))
								{
									ds_Signal s = (ds_Signal)slist.get(j).getBackIsoHT().get(charge);
									if (s.getHeight() < slist.get(i).getHeight()) // upmz & downmz範圍內有2個signal算出來的charge一樣，只保留那根高的
									{
										slist.get(j).getBackIsoHT().remove(charge);
										slist.get(j).getBackIsoHT().put(charge, slist.get(i));
									}
								}
								else
								{
									slist.get(j).getBackIsoHT().put(charge, slist.get(i));
								}

								//frontIsoHT
								if (slist.get(i).getFrontIsoHT().containsKey(charge))
								{
									ds_Signal s = (ds_Signal)slist.get(i).getFrontIsoHT().get(charge);
									if (s.getHeight() < slist.get(j).getHeight()) // 有2個signal算出來的charge一樣，只保留那根高的
									{
										slist.get(i).getFrontIsoHT().remove(charge);
										slist.get(i).getFrontIsoHT().put(charge, slist.get(j));
									}
								}
								else
								{
									slist.get(i).getFrontIsoHT().put(charge, slist.get(j));
								}
							}
						}
						else
						{
							break;
						}
					}
				}
			}
			ArrayList<ds_Signal> conSlist = new ArrayList<ds_Signal>();
			for (int i = 0; i < slist.size(); i++)
			{
				if (slist.get(i) != null)
				{
					conSlist.add(slist.get(i));
				}
			}
			slist.clear();
			Collections.sort(conSlist, new ds_Signal.MZComparison());

			ArrayList<ds_Peak> plist = new ArrayList<ds_Peak>();
			//Find isotope envelopes
			ArrayList<ds_Signal> temSlist = new ArrayList<ds_Signal>();
			temSlist.addAll(conSlist);
			Collections.sort(temSlist);
			for (int i = temSlist.size() - 1; i >= 0; i--)
			{
				if (!temSlist.get(i).isProcessed())
				{
					ds_Signal s = temSlist.get(i);
					boolean check = false;

					ds_Peak p = new ds_Peak();
					p.setMz(s.getMz());
					p.setRt(scan.RetentionTime);
					p.setHeight(s.getHeight());

					int index = conSlist.indexOf(s);
					int rindex = conSlist.indexOf(s);
					int lindex = conSlist.indexOf(s);
					for (int j = index; j < conSlist.size(); j++)
					{
						double mzdif = Math.abs(conSlist.get(j).getMz() - s.getMz());
						if (mzdif <= 0.1)
						{
							rindex = j;
						}
						else
						{
							break;
						}
					}
					for (int j = index; j >= 0; j--) // conSlist照mz排序，這裡找比s的mz還小的部份
					{
						double mzdif = Math.abs(conSlist.get(j).getMz() - s.getMz());
						if (mzdif <= 0.1)
						{
							lindex = j;
						}
						else
						{
							break;
						}
					}
					int count = Math.abs(rindex - lindex) + 1;
					if (count >= 3)
					{
						check = true;

						int buttom_index = conSlist.indexOf(s);
						int buttom_rindex = conSlist.indexOf(s);
						int buttom_lindex = conSlist.indexOf(s);
						double maxMZ = s.getMz() + 0.5f; // estimated fwhm (full width at half maximum)
						double minMZ = s.getMz() - 0.5f;

						for (int j = buttom_index; j < conSlist.size(); j++) //向右在 fwhm range (estimated) 外找 boundary
						{
							if (conSlist.get(j).getMz() > maxMZ) //conSlist照mz排序
							{
								break;
							}
							else
							{
								buttom_rindex = j;
							}
						}
						for (int j = buttom_index; j >= 0; j--) //向左在 fwhm range (estimated) 外找 boundary
						{
							if (conSlist.get(j).getMz() < minMZ)
							{
								break;
							}
							else
							{
								buttom_lindex = j;
							}
						}

						ArrayList<ds_IsoSignal> isoplist = new ArrayList<ds_IsoSignal>();
						for (int j = buttom_lindex; j <= buttom_rindex; j++)
						{
							ds_IsoSignal isop = new ds_IsoSignal();
							isop.setMz(conSlist.get(j).getMz());
							isop.setHeight(conSlist.get(j).getHeight());
							isoplist.add(isop); // 放所有 buttom_lindex及buttom_rindex中的signal (ds_IsoSignal)
							conSlist.get(j).setProcessed(true);
						}
						p.getIsopHT().put(-1, isoplist);
					}

					if (!check) // temSlist[i]左右 mz 0.1範圍內，signal個數小於3的情況
					{
						ArrayList ckey = new ArrayList(s.getBackIsoHT().keySet());
						Collections.sort(ckey);

						for (int j = ckey.size() - 1; j >= 0; j--)
						{
							if ((int)ckey.get(j) <= 10) //10+以下的才考慮 (9,8,7依序), 因為mz搜尋範圍只有 0.1，10個charge至少要有3個signal
							{ // ckey[j] 代表 charge值
								ArrayList<ds_Signal> isolist = new ArrayList<ds_Signal>();
								isolist.add(s); // s自己加到 isolist

								ds_Signal bisoS = s;
								double tempInt = bisoS.getHeight();
								while (bisoS != null)
								{
									if (bisoS.getBackIsoHT().containsKey(ckey.get(j)))
									{
										bisoS = (ds_Signal)bisoS.getBackIsoHT().get(ckey.get(j));
										if ((bisoS.getHeight() <= tempInt) && (!bisoS.isProcessed())) // 為何高度要越來越小，才加入isoList?
										{
											isolist.add(bisoS);
											tempInt = bisoS.getHeight();
										}
										else
										{
											break;
										}
									}
									else
									{
										break;
									}
								}

								ds_Signal fisoS = s;
								tempInt = fisoS.getHeight();
								while (fisoS != null)
								{
									if (fisoS.getFrontIsoHT().containsKey(ckey.get(j)))
									{
										fisoS = (ds_Signal)fisoS.getFrontIsoHT().get(ckey.get(j));
										if ((fisoS.getHeight() <= tempInt) && (!fisoS.isProcessed())) // 為何高度要越來越小，才加入isoList?
										{
											isolist.add(fisoS);
											tempInt = fisoS.getHeight();
										}
										else
										{
											break;
										}
									}
									else
									{
										break;
									}
								}

								Collections.sort(isolist, new ds_Signal.MZComparison()); //isolist照 mz排序
								int isoIndex = isolist.indexOf(s);
								if (isoIndex < (isolist.size() - 1)) //the highest peak is not the last one
								{
									ArrayList<ds_IsoSignal> isoplist = new ArrayList<ds_IsoSignal>();
									for (int k = isoIndex + 1; k < isolist.size(); k++) //只把mz大於s的signal加進來
									{
										ds_IsoSignal isop = new ds_IsoSignal();
										isop.setMz(isolist.get(k).getMz());
										isop.setHeight(isolist.get(k).getHeight());
										isoplist.add(isop);
										isolist.get(k).setProcessed(true);
									}
									p.getIsopHT().put(ckey.get(j), isoplist);
								}
								else //the highest peak is the last one
								{
									if (s.getBackIsoHT().containsKey(ckey.get(j)))
									{
										ds_Signal biso = (ds_Signal)s.getBackIsoHT().get(ckey.get(j));

										if ((biso.getHeight() > s.getHeight()) && (!biso.isProcessed()) && (biso.getBackIsoHT().containsKey(ckey.get(j))))
										{
											ds_IsoSignal isop = new ds_IsoSignal();
											isop.setMz(biso.getMz());
											isop.setHeight(biso.getHeight());

											ArrayList<ds_IsoSignal> isoplist = new ArrayList<ds_IsoSignal>();
											isoplist.add(isop);
											p.getIsopHT().put(ckey.get(j), isoplist);
											biso.setProcessed(true);
										}
									}
								}
							}
						}
					}
					plist.add(p);
				}
			}
			deIsopDic.put(scan.getNum(), plist);
		}

		return deIsopDic;
	}
}
