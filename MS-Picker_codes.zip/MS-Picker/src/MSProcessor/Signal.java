package MSProcessor;

import MSDataStructure.*;
import jdk.dynalink.linker.ConversionComparator;


import java.util.*;

public class Signal implements java.lang.Comparable<Signal> //Data Structure for Centroiding Points
{
	private double mz;
	public final double getMz()
	{
		return mz;
	}
	public final void setMz(double value)
	{
		mz = value;
	}
	private float height;
	public final float getHeight()
	{
		return height;
	}
	public final void setHeight(float value)
	{
		height = value;
	}
	private float area;
	public final float getArea()
	{
		return area;
	}
	public final void setArea(float value)
	{
		area = value;
	}
	private ArrayList<Signal> _slist = new ArrayList<Signal>();
	public final ArrayList<Signal> getSlist()
	{
		return _slist;
	}
	public final void setSlist(ArrayList<Signal> value)
	{
		_slist = value ;
	}

	static class MZComparison implements Comparator {
		public int compare(Object object1, Object object2) {
			Signal s1 = (Signal) object1;
			Signal s2 = (Signal) object2;
			return (new Double(s1.getMz())).compareTo(s2.getMz());
		}

	}
	public final int compareTo(Signal s)
	{
		return (new Float(getHeight())).compareTo(s.getHeight());
	}
}