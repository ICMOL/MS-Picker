package MSProcessor;

import MSDataStructure.*;
import java.util.*;

public class PointsCentroid
{
	public final MSPoints Centroid(MSPoints Points, double MZWidth)
	{
		MSPoints newPoints = new MSPoints();
        newPoints.mzList = new ArrayList<>();
		newPoints.heightList = new ArrayList<>();
		newPoints.areaList = new ArrayList<>();
		if (Points != null)
		{
			if (!Points.mzList.isEmpty())
			{
				//Data Structure Transform
				ArrayList<Signal> tempslist1 = new ArrayList<Signal>();
				for (int i = 0; i < Points.mzList.size(); i++)
				{
					if (Points.heightList.get(i) > 0)
					{
						Signal s = new Signal();
						s.setMz(Points.mzList.get(i));
						s.setHeight(Points.heightList.get(i));

						tempslist1.add(s);
					}
				}

				ArrayList<Signal> tempslist2 = new ArrayList<Signal>();
				//Clustering signals
				int L = 0;
				int T = 0;
				int K = 0;
				while (L < tempslist1.size())
				{
					Signal s1 = tempslist1.get(L);
					double mzTol = MZWidth * 1.5;
					double tempMaxIntensity = s1.getHeight();

					//cluster signals
					while (T < tempslist1.size())
					{
						Signal s2 = tempslist1.get(T);
						double tempmzdif = Math.abs(s2.getMz() - s1.getMz());
						if (tempmzdif <= mzTol)
						{
							if (s2.getHeight() >= tempMaxIntensity)
							{
								tempMaxIntensity = s2.getHeight();
								K = T;
								s1 = tempslist1.get(K);
							}
							T = T + 1;
						}
						else
						{
							break;
						}
					}

					double avgMZinterval = 0.0f;
					for (int a = L + 1; a < T; a++)
					{
						avgMZinterval += Math.abs(tempslist1.get(a).getMz() - tempslist1.get(a - 1).getMz());
					}
					avgMZinterval = avgMZinterval / (T - L);
					avgMZinterval = Double.isNaN(avgMZinterval) ? Double.NaN : Math.round(avgMZinterval * Math.pow(10, 3)) / Math.pow(10, 3) + 0.001f;
					while (T < tempslist1.size())
					{
						double tempmzdif = Math.abs(tempslist1.get(T).getMz() - tempslist1.get(T - 1).getMz());
						if (tempmzdif <= avgMZinterval)
						{
							if (tempslist1.get(T).getHeight() >= tempslist1.get(K).getHeight())
							{
								K = T;
							}
							T = T + 1;
						}
						else
						{
							break;
						}
					}
					for (int a = L; a < T; a++)
					{
						if (a != K)
						{
							tempslist1.get(K).getSlist().add(tempslist1.get(a));
							tempslist1.set(a, null);
						}
					}
					L = T;
				}

				for (int i = 0; i < tempslist1.size(); i++)
				{
					if (tempslist1.get(i) != null)
					{
						tempslist1.get(i).getSlist().add(tempslist1.get(i));
						tempslist2.add(tempslist1.get(i));
						tempslist1.set(i, null);
					}
				}
				tempslist1.clear();

				ArrayList<Signal> tempslist3 = new ArrayList<Signal>();
				//Check data mode: profile/centroid
				//a. Determine whether this scan is in profile/centroid mode, pick 50% of high intensity peaks.
				Collections.sort(tempslist2);
				int scount = 0;
				if (tempslist2.size() >= 4)
				{
					int listlength = (tempslist2.size() / 2) - 1;
					for (int i = listlength; i < tempslist2.size(); i++)
					{
						scount += tempslist2.get(i).getSlist().size();
					}
					scount = (scount / listlength) + 1;
				}
				else
				{
					for (int i = 0; i < tempslist2.size(); i++)
					{
						scount += tempslist2.get(i).getSlist().size();
					}
					scount = (scount / tempslist2.size()) + 1;
				}

				//b. If this scan is in profile mode, we have to separate peaks according to MZWidth
				if (scount >= 3)
				{
					for (int i = 0; i < tempslist2.size(); i++)
					{
						Signal s = tempslist2.get(i);
						Collections.sort(s.getSlist(), new Signal.MZComparison());

						double mzWidth = Math.abs(s.getSlist().get(0).getMz() - s.getSlist().get(s.getSlist().size() - 1).getMz());
						double mzTol2 = MZWidth * 2; //assume the peak is Gaussian Distribution
						double mzTol = mzTol2 / 2;
						if (mzWidth > mzTol2) //maybe co-elute
						{
							ArrayList<Signal> tempSlist = new ArrayList<Signal>();
							tempSlist.addAll(s.getSlist());
							Collections.sort(tempSlist);

							for (int j = tempSlist.size() - 1; j >= 0; j--)
							{
								if (tempSlist.get(j) != null)
								{
									Signal newS = new Signal();
									newS.setMz(tempSlist.get(j).getMz());
									newS.setHeight(tempSlist.get(j).getHeight());

									double lowInt = newS.getHeight();
									int rIndex = s.getSlist().indexOf(tempSlist.get(j)) + 1;
									for (int k = rIndex; k < s.getSlist().size(); k++)
									{
										if (s.getSlist().get(k) != null)
										{
											double mzdif = Math.abs(s.getSlist().get(k).getMz() - newS.getMz());
											if ((mzdif <= mzTol) || (s.getSlist().get(k).getHeight() <= lowInt))
											{
												lowInt = s.getSlist().get(k).getHeight();
												newS.getSlist().add(s.getSlist().get(k));
												tempSlist.set(tempSlist.indexOf(s.getSlist().get(k)), null);
												s.getSlist().set(k, null);
											}
											else
											{
												break;
											}
										}
										else
										{
											break;
										}
									}

									lowInt = newS.getHeight();
									int lIndex = s.getSlist().indexOf(tempSlist.get(j)) - 1;
									for (int k = lIndex; k >= 0; k--)
									{
										if (s.getSlist().get(k) != null)
										{
											double mzdif = Math.abs(s.getSlist().get(k).getMz() - newS.getMz());
											if ((mzdif <= mzTol) || (s.getSlist().get(k).getHeight() <= lowInt))
											{
												lowInt = s.getSlist().get(k).getHeight();
												newS.getSlist().add(s.getSlist().get(k));
												tempSlist.set(tempSlist.indexOf(s.getSlist().get(k)), null);
												s.getSlist().set(k, null);
											}
											else
											{
												break;
											}
										}
										else
										{
											break;
										}
									}

									newS.getSlist().add(tempSlist.get(j));
									s.getSlist().set(s.getSlist().indexOf(tempSlist.get(j)), null);
									tempSlist.set(j, null);
									tempslist3.add(newS);
								}
							}
						}
						else
						{
							tempslist3.add(s);
						}
					}

					//Calculate the area of a peak
					for (int i = 0; i < tempslist3.size(); i++)
					{
						Signal s = tempslist3.get(i);

						for (int j = 0; j < s.getSlist().size(); j++)
						{
							s.setArea(s.getArea() + s.getSlist().get(j).getHeight());
						}
					}
				}
				else
				{
					for (int i = 0; i < tempslist2.size(); i++)
					{
						tempslist2.get(i).setArea(tempslist2.get(i).getHeight());
					}
					tempslist3.addAll(tempslist2);
				}

				//Data Structure Transform: Signal->MSPoints
				Collections.sort(tempslist3, new Signal.MZComparison());
				for (int i = 0; i < tempslist3.size(); i++)
				{
					Signal s = tempslist3.get(i);
					newPoints.setMzList(s.getMz());
					newPoints.setHeightList(s.getHeight());
					newPoints.setAreaList(s.getArea());
				}
			}
		}

		return newPoints;
	}

	public final ArrayList<Double> SavitzkyGolay(ArrayList<Double> IntList, int filterWidth)
	{
		ArrayList<Double> smoothedIntList = new ArrayList<Double>();
		if (IntList == null)
		{
			return null;
		}
		else if (IntList.size() <= 1)
		{
			smoothedIntList.addAll(IntList);
			return smoothedIntList;
		}
		else
		{
			ArrayList<Double> tempList = new ArrayList<Double>();

			double[][] table = new double[4][];
			table[0] = new double[] {-3, 12, 17, 12, -3};
			table[1] = new double[] {-2, 3, 6, 7, 6, 3, -2};
			table[2] = new double[] {-21, 14, 39, 54, 59, 54, 39, 14, -21};
			table[3] = new double[] {-36, 9, 44, 69, 84, 89, 84, 69, 44, 9, -36};

			int extra = (table[filterWidth].length - 1) / 2;
			double sumOfFilter = 0;
			for (double value : table[filterWidth])
			{
				sumOfFilter += value;
			}

			//add pre node
			for (int i = 0; i < extra; i++)
			{
				tempList.add(IntList.get(0));
			}

			//add rawdata
			tempList.addAll(IntList);

			//add post node
			for (int i = 0; i < extra; i++)
			{
				tempList.add(IntList.get(IntList.size() - 1));
			}

			for (int i = extra; i < tempList.size() - extra; i++)
			{
				double sumwidth = 0.0f;
				for (int j = (-1 * extra); j <= extra; j++)
				{
					sumwidth += tempList.get(i + j) * table[filterWidth][j + extra];
				}
				double newy = sumwidth / sumOfFilter;
				smoothedIntList.add(newy);
			}

			//Savitzky Golay 可能會有小於0的y
			for (int i = 0; i < smoothedIntList.size(); i++)
			{
				if (smoothedIntList.get(i).compareTo((double) 0) < 0)
				{
					smoothedIntList.set(i, (double) 0);
				}
			}
			return smoothedIntList;
		}
	}
}