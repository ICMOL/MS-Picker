package MSProcessor;

import MSDataStructure.*;
import java.util.*;

public class NoiseRemoval
{
	public final MSScan RemoveNoise(MSScan Scan)
	{
		float freqInt = 0;
		//Calculate Background (Frequency)
		HashMap<Integer, Integer> tempDic = new HashMap<Integer, Integer>();
		for (int i = 0; i < Scan.Points.heightList.size(); i++)
		{
			int Height = Integer.parseInt(String.valueOf(Math.round(Scan.Points.heightList.get(i))));
			if (tempDic.containsKey(Height))
			{
				int count = tempDic.get(Height);
				count += 1;
				tempDic.remove(Height);
				tempDic.put(Height, count);
			}
			else
			{
				int count = 1;
				tempDic.put(Height, count);
			}
		}

		int maxCount = 0;
		for (int key : tempDic.keySet())
		{
			int count = tempDic.get(key);
			if (count > maxCount)
			{
				freqInt = Float.parseFloat(String.valueOf(key));
				maxCount = count;
			}
		}
		MSPoints points = new MSPoints();
		for (int i = 0; i < Scan.Points.heightList.size(); i++)
		{
			if (Scan.Points.heightList.get(i).compareTo(freqInt) > 0)
			{
				points.setMzList(Scan.Points.mzList.get(i));
				points.setHeightList(Scan.Points.heightList.get(i));
				points.setAreaList(Scan.Points.areaList.get(i));
			}
		}
		Scan.Points.mzList.clear();
		Scan.Points.heightList.clear();
		Scan.Points.areaList.clear();
		Scan.Points.setMzListAll(points.getMzList());
		Scan.Points.setHeightListAll(points.getHeightList());
		Scan.Points.setAreaListAll(points.getAreaList());
		Scan.setNoiseLevel(freqInt);

		return Scan;
	}

	public final MSScan RemoveNoise(MSScan Scan, float IntensityThreshold)
	{
		ArrayList<Double> mzlist = new ArrayList<Double>();
		ArrayList<Float> heightlist = new ArrayList<Float>();
		for (int i = 0; i < Scan.Points.mzList.size(); i++)
		{
			if (Scan.Points.heightList.get(i).compareTo(IntensityThreshold) >= 0)
			{
				mzlist.add(Scan.Points.mzList.get(i));
				heightlist.add(Scan.Points.heightList.get(i));
			}
		}
		Scan.Points.mzList.clear();
		Scan.Points.heightList.clear();
		Scan.Points.setMzListAll(mzlist);
		Scan.Points.setHeightListAll(heightlist);

		return Scan;
	}

	public final MSScan RemoveNoise(MSScan Scan, int SegNum, double NoiseFactor, double LowMZ, double HighMZ)
	{
		HashMap<Double, ArrayList<Double>> tempDic = new HashMap<Double, ArrayList<Double>>();

		//1.  計算interval
		double WindowWidth = (HighMZ - LowMZ) / SegNum;
		double upMZ = LowMZ;
		while (upMZ < HighMZ)
		{
			ArrayList<Double> HeightList = new ArrayList<Double>();
			tempDic.put(upMZ, HeightList);

			upMZ += WindowWidth;
		}
		ArrayList<Double> tlist = new ArrayList<Double>();
		tempDic.put(upMZ, tlist);

		//2. 紀錄hight
		ArrayList<Double> KeyList = new ArrayList<Double>(tempDic.keySet());
		Collections.sort(KeyList);
		for (int i = 0; i < Scan.Points.mzList.size(); i++)
		{
			double mz = Scan.Points.mzList.get(i);
			double height = Scan.Points.heightList.get(i);
			if (height > 0)
			{
				for (int j = 1; j < KeyList.size(); j++)
				{
					double down = KeyList.get(j - 1) * 0.8;
					double up = KeyList.get(j);
					if ((mz <= up) && (mz >= down))
					{
						ArrayList<Double> HeightList = tempDic.get(up);
						HeightList.add(height);
						break;
					}
				}
			}
		}

		//3. 計算 noise level
		HashMap<Double, Float> noiseDic = new HashMap<Double, Float>();
		for (double key : tempDic.keySet())
		{
			ArrayList<Double> HeightList = tempDic.get(key);
			float avgNoise = 0;
			for (int i = 0; i < HeightList.size(); i++)
			{
				avgNoise += HeightList.get(i);
			}
			if (!HeightList.isEmpty())
			{
				avgNoise = avgNoise / HeightList.size();
			}
			noiseDic.put(key, avgNoise);
		}

		MSPoints points = new MSPoints();
		points.mzList = new ArrayList<>();
		points.heightList = new ArrayList<>();
		points.areaList = new ArrayList<>();
		points.noiseList = new ArrayList<>();
		for (int j = 0; j < Scan.Points.mzList.size(); j++)
		{
			double mz = Scan.Points.mzList.get(j);
			float height = Scan.Points.heightList.get(j);
			float noise = 0;

			//find the noise level
			if (KeyList.size() > 1)
			{
				double mzdown = KeyList.get(0);
				double mzup = KeyList.get(KeyList.size() - 1);
				if (mz <= mzdown)
				{
					noise = noiseDic.get(mzdown);
				}
				else if (mz >= mzup)
				{
					noise = noiseDic.get(mzup);
				}
				else if ((mz >= mzdown) && (mz <= mzup))
				{
					int mzIndex = -1;
					for (int k = 0; k < KeyList.size(); k++)
					{
						if (mz <= KeyList.get(k))
						{
							mzIndex = k;
							break;
						}
					}
					noise = (noiseDic.get(KeyList.get(mzIndex - 1)) + noiseDic.get(KeyList.get(mzIndex))) / 2;
				}
			}
			else
			{
				noise = noiseDic.get(KeyList.get(KeyList.size() - 1));
			}

			double SN = height / noise;
			if (SN >= NoiseFactor)
			{
				points.setMzList(mz);
				points.setHeightList(height);
				points.setNoiseList(noise);
			}
		}
		Scan.Points.noiseList = new ArrayList<>();
		Scan.Points.mzList.clear();
		Scan.Points.heightList.clear();
		Scan.Points.areaList.clear();
		Scan.Points.setMzListAll(points.mzList);
		Scan.Points.setHeightListAll(points.heightList);
		Scan.Points.setAreaListAll(points.areaList);
		Scan.Points.setNoiseListAll(points.noiseList);

		return Scan;
	}
}