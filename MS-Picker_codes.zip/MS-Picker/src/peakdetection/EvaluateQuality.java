package peakdetection;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import jdistlib.disttest.NormalityTest;

public class EvaluateQuality { //eicMap: key=rt (min); value=Intensity

    public double calculateSW(double[] intAry) {
        // Shapiro-Wilk test回傳的值是一個介於0和1之間的數字。
        // 如果p值大於顯著性水平（例如，p > 0.05），
        // 則認為數據可以被假設為常態分佈。
        // 否則，如果p值小於顯著性水平，則認為數據不符合常態分佈的假設。
        try{
            Arrays.sort(intAry);
            return NormalityTest.shapiro_wilk_pvalue(NormalityTest.shapiro_wilk_statistic(intAry), intAry.length);
        }
        catch (Exception e){
            return Double.NaN;
        }
    }
    public double calculateNR(double[] intAry) {
        double NR = 0;
        int lastIndex = intAry.length - 1;
        double sum = intAry[0] + intAry[1] + intAry[lastIndex - 1] + intAry[lastIndex];
        NR = sum/4;
        double max = intAry[0];
        for (int i = 1; i < intAry.length; i++) {
            if (intAry[i] > max) {
                max = intAry[i];
            }
        }
        double SNR = max/NR;
        return NR;
    }

    public double calculateSlope(TreeMap<String, Double> eicMap) {
        double slope = 0;
        Map.Entry<String, Double> maxEntry = null;
        Map.Entry<String, Double> minEntry = null;
        for (Map.Entry<String, Double> entry : eicMap.entrySet()) {
            if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
                maxEntry = entry;
            if (minEntry == null || entry.getValue().compareTo(minEntry.getValue()) < 0)
                minEntry = entry;
        }
        double x1 = Double.parseDouble(minEntry.getKey()); //min_Int的RT
        double x2 = Double.parseDouble(maxEntry.getKey()); //max_Int的RT
        double y1 = minEntry.getValue(); //min_Int
        double y2 = maxEntry.getValue(); //max_Int
        slope = (y2 - y1) / (x2 - x1);
        return Math.abs(slope / 1000);
    }

    public double calculateZigZagIndex(TreeMap<String, Double> eicMap) {
        List<Double> eic = new ArrayList<>(eicMap.values());
        int end = eic.size();
        double EPI = Collections.max(eic) - (eic.get(0) + eic.get(1) + eic.get(end - 1) + eic.get(end - 2)) / 4.0;
        double zig_zag_sum = 0.0;
        for (int i = 1; i < end - 1; i++) {
            double local_zig_zag = Math.pow(2 * eic.get(i) - eic.get(i - 1) - eic.get(i + 1), 2);
            zig_zag_sum += local_zig_zag;
        }
        double zig_zag_index = zig_zag_sum / (Math.pow(EPI, 2) * end);
        return zig_zag_index;
    }

    public double calculateSymmetry(TreeMap<String, Double> eicMap) {
        List<Double> intensities = new ArrayList<>(eicMap.values());
        List<Double> left = new ArrayList<>();
        for (int i = 0; i < Math.floor(intensities.size() / 2); i++) {
            left.add(intensities.get(i));
        }
        List<Double> right = new ArrayList<>();
        for (int i = intensities.size() - 1; i >= intensities.size() - Math.floor(intensities.size() / 2); i--) {
            right.add(intensities.get(i));
        }
        float sum_X = 0, sum_Y = 0;
        float squareSum_X = 0, squareSum_Y = 0, sum_XY = 0;
        int n = left.size();
        for (int i = 0; i < n; i++) {
            sum_X = (float) (sum_X + left.get(i));
            sum_Y = (float) (sum_Y + right.get(i));
        }
        float mean_X = sum_X / n;
        float mean_Y = sum_Y / n;
        for (int i = 0; i < n; i++) {
            squareSum_X = (float) (squareSum_X + Math.pow(left.get(i) - mean_X, 2));
            squareSum_Y = (float) (squareSum_Y + Math.pow(right.get(i) - mean_Y, 2));
            //X and Y Combined
            sum_XY = (float) (sum_XY + (left.get(i) - mean_X) * (right.get(i) - mean_Y));
        }
        // use formula for calculating correlation coefficient
        double symmetry = (sum_XY / Math.sqrt(squareSum_X * squareSum_Y));
        return Math.abs(symmetry);
    }

    public double calculateSharpness(TreeMap<String, Double> eicMap) {
        List<Double> peak_intensity = new ArrayList<>(eicMap.values());
        int num_pk_pts = peak_intensity.size();
        double sharpness = 0;
        double apex_intensity = Collections.max(peak_intensity);
        int apex_index = 0;
        for (int i = 0; i < peak_intensity.size(); i++) {
            if (peak_intensity.get(i) == apex_intensity)
                apex_index = i;
        }
        if (num_pk_pts > 0) {
            for (int i = 0; i < num_pk_pts; i++) {
                if (i < apex_index - 1) {
                    sharpness = sharpness + (peak_intensity.get(i + 1) - peak_intensity.get(i)) / Math.max(0.0001, peak_intensity.get(i));
                } else if (i < num_pk_pts - 1) {
                    sharpness = sharpness + (peak_intensity.get(i) - peak_intensity.get(i + 1)) / Math.max(0.0001, peak_intensity.get(i + 1));
                }
            }
        }
        return sharpness;
    }

    public double calculateTPASR(double[] intAry) {
        double length = intAry.length;
        double sum = 0;
        double max_intensity = intAry[0];
        for (int i = 0; i < length; i++) {
            sum += intAry[i];
            if (intAry[i] > max_intensity) {
                max_intensity = intAry[i];
            }
        }

        double peak_area = sum;
        double triangular_area = 0.5 * length * max_intensity;
        double tpasr = Math.abs(triangular_area-peak_area)/triangular_area;
        return tpasr;
    }

    public double calculateApexMaxBoundary(TreeMap<String, Double> eicMap) {
        List<Double> peak_intensity = new ArrayList<>(eicMap.values());
        int num_pk_pts = peak_intensity.size();
        double max_intensity = Collections.max(peak_intensity);
        double max_boundary_intensity = Math.max(peak_intensity.get(0), peak_intensity.get(num_pk_pts - 1));
        return max_boundary_intensity / max_intensity;
    }

    public double calculatePeakSignificanceLevel(TreeMap<String, Double> eicMap) {
        List<Double> peak_intensity = new ArrayList<>(eicMap.values());
        int num_pk_pts = peak_intensity.size();
        double apex_intensity = Collections.max(peak_intensity);
        int apex_index = 0;
        for (int i = 0; i < peak_intensity.size(); i++) {
            if (peak_intensity.get(i) == apex_intensity)
                apex_index = i;
        }
        double peak_level = apex_intensity;
        double base_level = 0.0;
        // get peak significance, peak level, and base level
        double significance = 0;
        if (apex_index != 0 && apex_index != num_pk_pts - 1 && num_pk_pts > 3) {
            double sum1 = peak_intensity.get(0) + peak_intensity.get(1) + peak_intensity.get(num_pk_pts - 1) + peak_intensity.get(num_pk_pts - 2);
            double sum2 = peak_intensity.get(apex_index - 1) + peak_intensity.get(apex_index) + peak_intensity.get(apex_index + 1);
            significance = sum2 * 4.0 / (Math.max(sum1, 0.01) * 3.0);
        } else {
            return 0.0;
        }
        return significance;
    }
}
