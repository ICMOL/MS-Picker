package peakdetection;

import java.util.*;

public class ds_signal implements java.lang.Comparable<ds_signal>
{
    private double mz;
    public final double getMz()
    {
        return mz;
    }
    public final void setMz(double value)
    {
        mz = value;
    }
    private float rt;
    public final float getRt()
    {
        return rt;
    }
    public final void setRt(float value)
    {
        rt = value;
    }
    private float height;
    public final float getHeight()
    {
        return height;
    }
    public final void setHeight(float value)
    {
        height = value;
    }
    private float noiselevel;
    public final float getNoiselevel()
    {
        return noiselevel;
    }
    public final void setNoiselevel(float value)
    {
        noiselevel = value;
    }
    private ArrayList<ds_signal> _signallist = new ArrayList<ds_signal>();
    private HashMap<Integer, ds_signal> _backIsoDic = new HashMap<Integer, ds_signal>(); //紀錄跟隨的 isotopic peak
    private boolean isIsoSignal;
    public final boolean isIsoSignal()
    {
        return isIsoSignal;
    }
    public final void setIsoSignal(boolean value)
    {
        isIsoSignal = value;
    }
    private int ScanNum;
    public final int getScanNum()
    {
        return ScanNum;
    }
    public final void setScanNum(int value)
    {
        ScanNum = value;
    }
    static class MZComparison implements Comparator {
        public int compare(Object object1, Object object2) {
            ds_signal s1 = (ds_signal) object1;
            ds_signal s2 = (ds_signal) object2;
            return (int) Math.round(s1.getMz() - s2.getMz());//s1.getMz() - s2.getMz()
//            return new Double(s1.getMz()).compareTo(s2.getMz());
        }
    }

    static class RTComparison implements Comparator {//20220719修改20220720改

        @Override
        public int compare(Object o1, Object o2) {
            ds_signal s1 = (ds_signal) o1;
            ds_signal s2 = (ds_signal) o2;
            Float f1 = new Float(s1.getRt());//20220720修改//getHeight
            Float f2 = new Float(s2.getRt());//20220720修改//getHeight
            return f1.compareTo(f2);//s1.getRt//20220719修改
//            return (int) Math.round(s1.getHeight() - s2.getHeight());//s1.getRt
        }

//        static class RTComparison implements Comparator {
//
//            @Override
//            public int compare(Object o1, Object o2) {
//                ds_pdSignal s1 = (ds_pdSignal) o1;
//                ds_pdSignal s2 = (ds_pdSignal) o2;
//                return (int) Math.round(s1.rt - s2.rt);
//            }
//        public int compare(Object object1, Object object2) {
//            ds_pdSignal s1 = (ds_pdSignal) object1;
//            ds_pdSignal s2 = (ds_pdSignal) object2;
//            return new Float(s1.getRt()).compareTo(s2.getRt());
//        }
    }
//    Collection.sort(allrncplist,new Comparator<ds_pdSignal>(){
//    public int compare (ds_Signal p1,ds_Signal p2){return (int)((p1.height)-(p2.height));}});
/*
    public static ConversionComparator.Comparison MZComparison = (ds_pdSignal s1, ds_pdSignal s2) ->
    {
        return  Double.compare(s1.getMz(),s2.getMz());
    };
    public static ConversionComparator.Comparison RTComparison = (ds_pdSignal s1, ds_pdSignal s2) ->
    {
        return (Double.compare((s1.getRt()),(s2.getRt()));
    };
 */
    public final ArrayList<ds_signal> getSignallist()
    {
        return _signallist;
    }
    public final void setSignallist(ArrayList<ds_signal> value)
    {
        _signallist = value;
    }
    public final HashMap<Integer, ds_signal> getBackIsoDic()
    {
        return _backIsoDic;
    }
    public final void setBackIsoDic(HashMap<Integer, ds_signal> value)
    {
        _backIsoDic = value;
    }
    public final int compareTo(ds_signal s)
    {
        return (new Float(getHeight())).compareTo(s.getHeight());
    }
    public int compare(ds_signal a, ds_signal b)
    {
        return (int) Math.round(a.getHeight() - b.getHeight());
    }
}