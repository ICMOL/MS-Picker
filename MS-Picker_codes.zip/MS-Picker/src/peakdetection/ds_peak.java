package peakdetection;

import java.lang.*;
import java.lang.Double;
import java.util.*;

class ds_peak implements java.lang.Comparable<ds_peak>
{
    private ds_signal _centralSignal = new ds_signal(); //儲存cluster的中心Signal
    public ArrayList<ds_signal> _signallist = new ArrayList<ds_signal>(); //儲存每一個scan的central signal
    private int charge;
    public final int getCharge()
    {
        return charge;
    }
    public final void setCharge(int value)
    {
        charge = value;
    }
    private float isoRatio;
    public final float getIsoRatio()
    {
        return isoRatio;
    }
    public final void setIsoRatio(float value)
    {
        isoRatio = value;
    }
    private String isoStr;
    public final String getIsoStr()
    {
        return isoStr;
    }
    public final void setIsoStr(String value)
    {
        isoStr = value;
    }
    private int qCoeluted;
    public final int getQCoeluted()
    {
        return qCoeluted;
    }
    public final void setQCoeluted(int value)
    {
        qCoeluted = value;
    }
    private int qCharge;
    public final int getQCharge()
    {
        return qCharge;
    }
    public final void setQCharge(int value)
    {
        qCharge = value;
    }
    private int qShape;
    public final int getQShape()
    {
        return qShape;
    }
    public final void setQShape(int value)
    {
        qShape = value;
    }
    private int qPoint;
    public final int getQPoint()
    {
        return qPoint;
    }
    public final void setQPoint(int value)
    {
        qPoint = value;
    }

    static class MZComparison implements Comparator {
        public int compare(Object object1, Object object2) {
            ds_peak p1 = (ds_peak) object1;
            ds_peak p2 = (ds_peak) object2;
            return new Double(p1.getCentralSignal().getMz()).compareTo(p2.getCentralSignal().getMz());
        }


    }

    static class RTComparison implements Comparator {//20220726前版本
        public int compare(Object object1, Object object2) {
            ds_peak p1 = (ds_peak) object1;
            ds_peak p2 = (ds_peak) object2;
            Float f1 = new Float(p1.getCentralSignal().getRt());//20220724修改
            Float f2 = new Float(p2.getCentralSignal().getRt());//20220724修改
            return compareTo2(f1,f2);
        }
    }

    public final ds_signal getCentralSignal()
    {
        return _centralSignal;
    }
    public final void setCentralSignal(ds_signal value)
    {
        _centralSignal = value;
    }
    public final ArrayList<ds_signal> getSignallist()
    {
        return _signallist;
    }
    public final void setSignallist(ArrayList<ds_signal> value)
    {
        _signallist = value;
    }
    public final int compareTo(ds_peak p)
    {
        int cindex = 0;
        if (getCentralSignal().getHeight() < p.getCentralSignal().getHeight()) //<
        {
            cindex = -1;
        }
        else if (getCentralSignal().getHeight() > p.getCentralSignal().getHeight()) //>
        {
            cindex = 1;
        }
        else //=
        {
            if (getCentralSignal().getMz() < p.getCentralSignal().getMz())
            {
                cindex = 1;
            }
            else if (getCentralSignal().getMz() > p.getCentralSignal().getMz())
            {
                cindex = -1;
            }
        }
        return cindex;
    }

    public static final int compareTo2(double p1, double p2){
        if(p1<p2) return -1;
        else if(p1>p2) return 1;
        else return 0;
    }
}