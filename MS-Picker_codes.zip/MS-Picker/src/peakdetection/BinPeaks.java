package peakdetection;

import java.util.*;
import java.util.stream.Collectors;

public class BinPeaks
{
    public final void binPeaks(ds_peak p, float pdMZTol, float rtTol, TreeMap<Integer, ArrayList<ds_peak>> pcMap)
    {
        List<Integer> keyLi = pcMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(keyLi);
        //1. 找合適的mz bin
        ArrayList<Integer> index = FindtheMZBin(p, keyLi);

        //2. 找合適的peak cluster
        ArrayList<Object> bestlist = Findbestpc(p, index, pdMZTol, rtTol, pcMap, keyLi);

        //3. Assign peak to the best peak cluster將峰值分配給最佳峰值群集
        AssigntheBestPeakCluster((Boolean)bestlist.get(0), (ds_peak)bestlist.get(1), (Boolean)bestlist.get(2), (Integer)bestlist.get(3), p, pcMap);
    }

    public final void AssigntheBestPeakCluster(boolean findbestpc, ds_peak bestpc, boolean findbestmz, int bestkey, ds_peak p, TreeMap<Integer, ArrayList<ds_peak>> pcMap)
    {
        if (findbestpc) //代表有找到最合適的, including mz,rt
        {
            //1. 先比較intensity, 要找central signal, 若是bestpc的intensity小於p的intensity,則central signal換p
            if (bestpc.getCentralSignal().getHeight() <= p.getCentralSignal().getHeight())
            {
                bestpc.getCentralSignal().setMz(p.getCentralSignal().getMz());
                bestpc.getCentralSignal().setRt(p.getCentralSignal().getRt());
                bestpc.getCentralSignal().setHeight(p.getCentralSignal().getHeight());
            }

            //2. 將新加入的peak中所有signal都加入bestpc中
            bestpc.getSignallist().addAll(p.getSignallist());
        }
        else if (findbestmz)
        {
            ArrayList<ds_peak> pclist = pcMap.get(bestkey);
            pclist.add(p);
        }
        else //代表此peak沒有最接近的mz key值
        {
            if (pcMap.containsKey(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz())))))
            {
                ArrayList<ds_peak> pclist = pcMap.get(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))));
                pclist.add(p);
            }
            else
            {
                ArrayList<ds_peak> pclist = new ArrayList<ds_peak>();
                pclist.add(p);
                pcMap.put(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))), pclist);//(int)Math.round
            }
        }
    }

    public final ArrayList<Object> Findbestpc(ds_peak p, ArrayList<Integer> index, float mzTol, float rtTol, TreeMap<Integer, ArrayList<ds_peak>> pcMap, List<Integer> keyLi)
    {
        ArrayList<Object> bestlist = new ArrayList<Object>();
        double minCov = 10000f;
        double minmzd = 10000f;
        boolean findbestpc = false;
        ds_peak bestpc = null;
        boolean findbestmz = false;
        int bestkey = -1;
        for (int i = 0; i < index.size(); i++)
        {
            if (index.get(i).compareTo(-1) > 0) //代表可能的m/z bin
            {
                ArrayList<ds_peak> pclist = pcMap.get(keyLi.get(index.get(i)));
                for (int k3 = 0; k3 < pclist.size(); k3++)
                {
                    ds_peak pc = pclist.get(k3);

                    double upmz = pc.getCentralSignal().getMz() + mzTol;
                    double downmz = pc.getCentralSignal().getMz() - mzTol;
                    Collections.sort(pc._signallist, new ds_signal.RTComparison());
                    float uprt = pc.getSignallist().get(pc.getSignallist().size() - 1).getRt() + rtTol;
                    float downrt = pc.getSignallist().get(0).getRt() - rtTol;

                    if ((p.getCentralSignal().getMz() <= upmz) && (p.getCentralSignal().getMz() >= downmz))
                    {
                        if ((p.getCentralSignal().getRt() <= uprt) && (p.getCentralSignal().getRt() >= downrt))
                        {
                            double cov = Math.abs(p.getCentralSignal().getMz() - pc.getCentralSignal().getMz()) * Math.abs(p.getCentralSignal().getRt() - pc.getCentralSignal().getRt()); //計算Cov
                            if (cov < minCov) //有找到最合適的
                            {
                                findbestpc = true;
                                bestpc = pc;
                            }
                        }
                        else
                        {
                            double mzdif = Math.min(Math.abs(p.getCentralSignal().getMz() - upmz), Math.abs(p.getCentralSignal().getMz() - downmz));
                            if (mzdif <= minmzd)
                            {
                                findbestmz = true;
                                bestkey = (int)(keyLi.get(index.get(i)));//(int)Math.round
                                minmzd = mzdif;
                            }
                        }
                    }
                }
            }
        }

        bestlist.add(findbestpc);
        bestlist.add(bestpc);
        bestlist.add(findbestmz);
        bestlist.add(bestkey);
        return bestlist;
    }

    public final ArrayList<Integer> FindtheMZBin(ds_peak p, List<Integer> keyLi)
    {
        ArrayList<Integer> index = new ArrayList<Integer>(); //儲存index
        int a2 = keyLi.indexOf(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))));//(int)Math.round，indexOf:需要搜索其索引的元素e[mz值在keyLi的位置]
        if (a2 == -1) //代表 Dictionary 中沒有此 key 值, 要確認是否有包含 -1 or +1
        {
                a2 = keyLi.indexOf(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))) + 1);//(int)
        }
        if (a2 == -1)
        {
            a2 = keyLi.indexOf(Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))) - 1);
        }
        int a1 = -1;
        int a3 = -1;
        if ((a2 > 1) && (a2 < (keyLi.size() - 1))) //a2在範圍內
        {
            a1 = a2 - 1;
            a3 = a2 + 1;
        }

        index.add(a1);
        index.add(a2);
        index.add(a3);

        for (int i = 0; i < index.size(); i++)
        {
            if (index.get(i).compareTo(-1) > 0)
            {
                int dif = Math.abs((int)(keyLi.get(index.get(i))) - Integer.parseInt(String.valueOf(Math.round(p.getCentralSignal().getMz()))));//(int)Math.round
                if (dif >= 3) //超過進位的可能
                {
                    index.set(i, -1);
                }
            }
        }
       return index;
    }
}
