 package peakdetection;

 import MSDataStructure.*;
 import MSProcessor.*;
 import MSReader.*;

 import java.util.*;
 import java.io.*;
 import java.util.stream.Collectors;
 import java.lang.*;

 public class pdStart
 {
     private String getFileExtension(String filename) {
         //String name = file.getName();
         int lastIndexOf = filename.lastIndexOf(".");
         if (lastIndexOf == -1) {
             return ""; // empty extension
         }
         return filename.substring(lastIndexOf);
     }
     private float rtTolbyScan = 0.0f; //rt in sec

     public final void process(String input, String output,
             float NoiseLevel_inSpectrum, float NoiseFactor, int SegNum, float minRT, float maxRT,
             float mzWidth, int MinIons, float Similarity)
     {
         rtTolbyScan = 0.0f;
         int sec = 1000;
         long startTime=System.currentTimeMillis();

         //1. 載入資料, Centroid each spectrum
         MSRawData raw = LoadData(input, mzWidth, minRT, maxRT); // msrawdata要改or加
         long endTime = System.currentTimeMillis();
         //System.out.println("Data loading: "+(endTime-startTime)/sec+" sec.");

         //2. Subtract the baseline from each spectrum and data transform
         long endTime1_1 = System.currentTimeMillis();
         TreeMap<Integer, ArrayList<ds_peak>> dataMap = BaselineSubtractionandDataTransform(raw, NoiseLevel_inSpectrum, NoiseFactor, SegNum);
         long endTime2 = System.currentTimeMillis();
         //System.out.println("Noise removal: "+(endTime2-endTime1_1)/sec+" sec.");

         //4. Deisotoping
         long endTime2_1 = System.currentTimeMillis();
         TreeMap<Integer, ArrayList<ds_peak>> deIsopMap = Deisotoping(dataMap, mzWidth);
         long endTime3 = System.currentTimeMillis();
         //System.out.println("Deisotoping: "+(endTime3-endTime2_1)/sec+" sec.");

         //5. ClusterPeak, by scan
         long endTime3_1 = System.currentTimeMillis();
         TreeMap<Integer, ArrayList<ds_peak>> pcMap = ClusterPeak(deIsopMap, mzWidth);
         long endTime4 = System.currentTimeMillis();
         //System.out.println("Clustering I: "+(endTime4-endTime3_1)/sec+" sec.");

         //6. Cluster by intensity
         long endTime4_1 = System.currentTimeMillis();
         TreeMap<Integer, ArrayList<ds_peak>> allpcMap = ClusterByIntensity(pcMap, mzWidth, 5);
         long endTime5 = System.currentTimeMillis();
         //System.out.println("Clustering II: "+(endTime5-endTime4_1)/sec+" sec.");

         //7. Extract peaks
         long endTime5_1 = System.currentTimeMillis();
         minRT = minRT - 10;
         maxRT = maxRT + 10;
         float ePeakWdith = Math.abs(maxRT - minRT) * 0.1f;
         int MaxPeakWdith = Integer.parseInt(String.valueOf(Math.round(ePeakWdith)));
         TreeMap<Integer, ArrayList<ds_peak>> NewpcMap = ExtractPeaks(allpcMap, MinIons, MaxPeakWdith);
         long endTime6 = System.currentTimeMillis();
         //System.out.println("Ion chromatogram extraction: "+(endTime6-endTime5_1)/sec+" sec.");

         //8. Charge State Determination
         long endTime6_1 = System.currentTimeMillis();
         ArrayList<ds_peak> allplist = ChargeStateDetermination(NewpcMap, Similarity, MinIons);
         long endTime7 = System.currentTimeMillis();
         //System.out.println("Charge state determination: "+(endTime7-endTime6_1)/sec+" sec.");

         //9. print
         long endTime7_1 = System.currentTimeMillis();
         PrintResult(input, output, allplist);
         long endTime8 = System.currentTimeMillis();
         //System.out.println("Printing: "+(endTime8-endTime7_1)/sec+" sec.");
     }

     public final MSRawData LoadData(String fName, float mzWidth, float minRT, float maxRT)
     {
         MSRawData raw = new MSRawData();
         if (getFileExtension(fName).equals(".mzML"))
         {
             mzMLReader reader = new mzMLReader();
             raw = reader.ReadmzML(fName, mzWidth, minRT, maxRT, 1);
         }
         return raw;
     }

     public final TreeMap<Integer, ArrayList<ds_peak>> BaselineSubtractionandDataTransform(MSRawData raw, float NoiseLevel_inSpectrum, float NoiseFactor, int SegNum)
     {
         TreeMap<Integer, ArrayList<ds_peak>> dataMap = new TreeMap<Integer, ArrayList<ds_peak>>();
         NoiseRemoval nr = new NoiseRemoval();
         float rt1 = 0.0f;
         int count = 0;

         var key = raw.ScanDic.keySet().toArray(new Integer[0]);
         Arrays.sort(key);
         for (int i = 0; i < key.length; i++)
         {
             MSScan scan = raw.ScanDic.get(key[i]);
             //Perform Noise Removal
             if (NoiseLevel_inSpectrum > 0)
             {
                 scan = nr.RemoveNoise(scan, NoiseLevel_inSpectrum);
             }
             else
             {
                 scan = nr.RemoveNoise(scan, SegNum, NoiseFactor, raw.GlobalLowMZ, raw.GlobalHighMZ);
             }

             ArrayList<ds_peak> plist = new ArrayList<ds_peak>();

             //Transform Data
             for (int j = 0; j < scan.Points.mzList.size(); j++)
             {
                 ds_signal s = new ds_signal();
                 s.setMz(scan.Points.mzList.get(j));
                 s.setRt(scan.getRetentionTime());
                 s.setHeight(scan.Points.heightList.get(j));
                 if (NoiseLevel_inSpectrum < 0)
                 {
                     s.setNoiselevel(scan.Points.noiseList.get(j));
                 }
                 else
                 {
                     s.setNoiselevel(NoiseLevel_inSpectrum);
                 }

                 s.setScanNum(scan.getNum());
                 ds_peak p = new ds_peak();
                 p.getCentralSignal().setMz(scan.Points.mzList.get(j));
                 p.getCentralSignal().setRt(scan.getRetentionTime());
                 p.getCentralSignal().setHeight(scan.Points.heightList.get(j));

                 p.getSignallist().add(s);
                 plist.add(p);
             }

             //Calculate rtgap
             if (count == 0)
             {
                 rt1 = scan.getRetentionTime();
             }
             else
             {
                 float rt2 = scan.getRetentionTime();
                 float rtTol = Math.abs(rt1 - rt2);

                 if (rtTol > rtTolbyScan)
                 {
                     rtTolbyScan = rtTol;
                 }
                 rt1 = rt2;
             }
             count += 1;
             dataMap.put(key[i], plist);
         }
         raw.Dispose();

         return dataMap;
     }

     public final TreeMap<Integer, ArrayList<ds_peak>> Deisotoping(TreeMap<Integer, ArrayList<ds_peak>> dataMap, float pdMZTol)
     {
         TreeMap<Integer, ArrayList<ds_peak>> deIsopMap = new TreeMap<Integer, ArrayList<ds_peak>>();
         float MZTol = pdMZTol * 1.5f;
         float searchRange = 1.003f + MZTol;
         for (int ScanNum : dataMap.keySet())
         {
             ArrayList<ds_peak> deIsoplist = new ArrayList<ds_peak>();
             ArrayList<ds_peak> plist = dataMap.get(ScanNum);
             Collections.sort(plist, new ds_peak.MZComparison());

             for (int i = plist.size() - 1; i >= 0; i--)
             {
                 if (plist.get(i) != null)
                 {
                     for (int j = i - 1; j >= 0; j--)
                     {
                         double mzdif = Math.abs(plist.get(i).getCentralSignal().getMz() - plist.get(j).getCentralSignal().getMz());
                         if (mzdif <= pdMZTol)
                         {
                             if (plist.get(i).getCentralSignal().getHeight() >= plist.get(j).getCentralSignal().getHeight())
                             {
                                 plist.set(j, null);
                             }
                             else
                             {
                                 plist.set(i, null);
                                 break;
                             }
                         }
                         else if ((mzdif > pdMZTol) && (mzdif <= searchRange))
                         {
                             int charge =Integer.parseInt(String.valueOf(Math.round(1.0 / mzdif)));
                             double upmz = plist.get(j).getCentralSignal().getMz() + (1.0f / ((float)charge)) + MZTol;
                             double downmz = plist.get(j).getCentralSignal().getMz() + (1.0f / ((float)charge)) - MZTol;

                             if ((plist.get(i).getCentralSignal().getMz() <= upmz) && (plist.get(i).getCentralSignal().getMz() >= downmz))
                             {
                                 //backIsoDic
                                 if (plist.get(j).getSignallist().get(0).getBackIsoDic().containsKey(charge))
                                 {
                                     ds_signal s = plist.get(j).getSignallist().get(0).getBackIsoDic().get(charge);
                                     if (s.getHeight() < plist.get(i).getSignallist().get(0).getHeight())
                                     {
                                         plist.get(j).getSignallist().get(0).getBackIsoDic().remove(charge);
                                         plist.get(j).getSignallist().get(0).getBackIsoDic().put(charge, plist.get(i).getSignallist().get(0));
                                     }
                                 }
                                 else
                                 {
                                     plist.get(j).getSignallist().get(0).getBackIsoDic().put(charge, plist.get(i).getSignallist().get(0));
                                 }
                             }
                         }
                         else
                         {
                             break;
                         }
                     }
                 }
             }

             for (int i = 0; i < plist.size(); i++)
             {
                 if (plist.get(i) != null)
                 {
                     deIsoplist.add(plist.get(i));
                 }
             }
             plist.clear();
             Collections.sort(deIsoplist, new ds_peak.MZComparison());
             deIsopMap.put(ScanNum, deIsoplist);
         }
         return deIsopMap;
     }

     public final TreeMap<Integer, ArrayList<ds_peak>> ClusterPeak(TreeMap<Integer, ArrayList<ds_peak>> deIsopMap, float pdMZTol)
     {
         TreeMap<Integer, ArrayList<ds_peak>> pcMap = new TreeMap<Integer, ArrayList<ds_peak>>();
         BinPeaks cp = new BinPeaks();
         int count = 0;
         List<Integer> key = deIsopMap.keySet().stream().collect(Collectors.toList());
         Collections.sort(key);
         for (int i = 0; i < key.size(); i++)
         {
             ArrayList<ds_peak> plist = deIsopMap.get(key.get(i));
             for (int j = 0; j < plist.size(); j++)
             {
                 ds_peak p = plist.get(j);
                 cp.binPeaks(p, pdMZTol, rtTolbyScan, pcMap);
             }
             count += plist.size();
         }
         return pcMap;
     }

     public final TreeMap<Integer, ArrayList<ds_peak>> ClusterByIntensity(TreeMap<Integer, ArrayList<ds_peak>> pcDic, float pdMZTol, int scanCount)
     {
         TreeMap<Integer, ArrayList<ds_peak>> allpcDic = new TreeMap<Integer, ArrayList<ds_peak>>();
         for (int MZChannel : pcDic.keySet())
         {
             ArrayList<ds_peak> plist = pcDic.get(MZChannel);
             ArrayList<ds_peak> Mergeplist = new ArrayList<ds_peak>();

             if (plist.size() > 1) //一個以上的才需要做merge的動作
             {
                 ArrayList<ds_peak> templist = new ArrayList<ds_peak>();
                 templist.addAll(plist);
                 Collections.sort(templist); //依照intensity由小到大排序

                 for (int i = templist.size() - 1; i >= 0; i--)
                 {
                     if (templist.get(i) != null)
                     {
                         ds_peak p = templist.get(i);

                         ArrayList<ds_peak> mplist = new ArrayList<ds_peak>();

                         //region 要先做mz的clustering動作, 先找出符合mzTol的possible peak, 使用overlap

                         for (int k = 0; k < templist.size(); k++)
                         {
                             if (templist.get(k) != null)
                             {
                                 double mzdif = Math.abs(p.getCentralSignal().getMz() - templist.get(k).getCentralSignal().getMz());
                                 if (mzdif <= pdMZTol)
                                 {
                                     mplist.add(templist.get(k));
                                 }
                             }
                         }

                         //endregion

                         if (mplist.size() > 1) //代表有split的peak
                         {
                             Collections.sort(mplist, new ds_peak.RTComparison());
                             //region 向右merge peak
                             int rightindex = mplist.indexOf(p);
                             while (rightindex < (mplist.size() - 1))
                             {
                                 ds_peak rightpeak = mplist.get(rightindex + 1);

                                 Collections.sort(p.getSignallist(), new ds_signal.RTComparison());
                                 Collections.sort(rightpeak.getSignallist(), new ds_signal.RTComparison());

                                 float scandif = rightpeak.getSignallist().get(0).getScanNum() - p.getSignallist().get(p.getSignallist().size() - 1).getScanNum();

                                 if (scandif <= scanCount) //如果兩個peak為鄰近的點
                                 {
                                     p.getSignallist().addAll(mplist.get(rightindex + 1).getSignallist()); //把新的peak加入centralpeak中
                                     templist.set(templist.indexOf(mplist.get(rightindex + 1)), null);
                                 }
                                 else
                                 {
                                     break;
                                 }
                                 rightindex += 1;
                             }

                             //endregion

                             //region 向左merge peak
                             int leftindex = mplist.indexOf(p);
                             while (leftindex > 0)
                             {
                                 ds_peak leftpeak = mplist.get(leftindex - 1);

                                 Collections.sort(p.getSignallist(), new ds_signal.RTComparison());
                                 Collections.sort(leftpeak.getSignallist(), new ds_signal.RTComparison());

                                 float scandif = p.getSignallist().get(0).getScanNum() - leftpeak.getSignallist().get(leftpeak.getSignallist().size() - 1).getScanNum();

                                 if (scandif <= scanCount) //如果兩個peak為鄰近的點
                                 {
                                     p.getSignallist().addAll(mplist.get(leftindex - 1).getSignallist()); //把新的peak加入centralpeak中
                                     templist.set(templist.indexOf(mplist.get(leftindex - 1)), null);
                                 }
                                 else
                                 {
                                     break;
                                 }
                                 leftindex -= 1;
                             }

                             //endregion
                         }

                         //確定每一個scan上只有一個signal, Key: rt, Value: signal
                         HashMap<Float, ds_signal> tempDic = new HashMap<Float, ds_signal>();
                         for (int j = 0; j < p.getSignallist().size(); j++)
                         {
                             if (tempDic.containsKey(p.getSignallist().get(j).getRt()))
                             {
                                 ds_signal tmpS = tempDic.get(p.getSignallist().get(j).getRt());
                                 if (tmpS.getHeight() <= p.getSignallist().get(j).getHeight())
                                 {
                                     tempDic.remove(p.getSignallist().get(j).getRt());
                                     tempDic.put(p.getSignallist().get(j).getRt(), p.getSignallist().get(j));
                                 }
                             }
                             else
                             {
                                 tempDic.put(p.getSignallist().get(j).getRt(), p.getSignallist().get(j));
                             }
                         }
                         p.getSignallist().clear();
                         for (ds_signal s : tempDic.values())
                         {
                             p.getSignallist().add(s);
                         }

                         Mergeplist.add(p);
                         templist.set(i, null);
                     }
                 }
             }
             else
             {
                 Mergeplist.addAll(plist);
             }
             allpcDic.put(MZChannel, Mergeplist);
         }
         pcDic.clear();

         return allpcDic;
     }

     public final TreeMap<Integer, ArrayList<ds_peak>> ExtractPeaks(TreeMap<Integer, ArrayList<ds_peak>> allpcMap, int MinIons, int MaxPeakWdith)
     {
         TreeMap<Integer, ArrayList<ds_peak>> newpcMap = new TreeMap<Integer, ArrayList<ds_peak>>();

         for (int MZChannel : allpcMap.keySet())
         {
             ArrayList<ds_peak> plist = allpcMap.get(MZChannel);
             ArrayList<ds_peak> newplist = new ArrayList<ds_peak>();
             for (int i = 0; i < plist.size(); i++)
             {
                 ds_peak p = plist.get(i);
                 if (p.getSignallist().size() >= MinIons)
                 {
                     Collections.sort(p.getSignallist(), new ds_signal.RTComparison());
                     ArrayList<ds_peak> templist = new ArrayList<ds_peak>(); //儲存此peak, 若此peak有coelute, 則可能會有多個peaks+

                     //split peaks
                     ArrayList<ds_signal> temslist = new ArrayList<ds_signal>();
                     temslist.addAll(p.getSignallist());
                     Collections.sort(temslist); // 按照intensity 排序
                     for (int j = temslist.size() - 1; j >= 0; j--)
                     {
                         if (temslist.get(j) != null)
                         {
                             ds_signal s = temslist.get(j);

                             int midIndex = p.getSignallist().indexOf(s);
                             int rboundIndex = p.getSignallist().size() - 1;
                             int lboundIndex = 0;
                             //左右找第一個null, 當成這個peak的 boundary
                             for (int k = midIndex; k < p.getSignallist().size(); k++)
                             {
                                 if (p.getSignallist().get(k) == null)
                                 {
                                     rboundIndex = k - 1;
                                     break;
                                 }
                             }
                             for (int k = midIndex; k >= 0; k--)
                             {
                                 if (p.getSignallist().get(k) == null)
                                 {
                                     lboundIndex = k + 1;
                                     break;
                                 }
                             }

                             int rhIndex = rboundIndex;
                             int lhIndex = lboundIndex;
                             //region 找半高寬 rthWidth
                             float hInt = s.getHeight() / 2; //半高寬
                             for (int k = midIndex; k <= rboundIndex; k++) //向右找一半的高度
                             {
                                 rhIndex = k;
                                 if (p.getSignallist().get(k).getHeight() <= hInt)
                                 {
                                     break;
                                 }
                             }
                             for (int k = midIndex; k >= lboundIndex; k--) //向左找一半的高度
                             {
                                 lhIndex = k;
                                 if (p.getSignallist().get(k).getHeight() <= hInt)
                                 {
                                     break;
                                 }
                             }

                             float rthWidth = Math.abs(p.getSignallist().get(rhIndex).getRt() - p.getSignallist().get(lhIndex).getRt());
                             float rtbWidth = rthWidth * 2f;
                             float rtThresold = (rthWidth / 2) * 1.5f;
                             float pWidth = Math.abs(p.getSignallist().get(rboundIndex).getRt() - p.getSignallist().get(lboundIndex).getRt());
                             if (pWidth > rtbWidth) //代表可能有coelute
                             {
                                 int rbIndex = rhIndex;
                                 float rbInt = p.getSignallist().get(rbIndex).getHeight();
                                 int lbIndex = lhIndex;
                                 float lbInt = p.getSignallist().get(lbIndex).getHeight();
                                 //找 boundary
                                 float rtright = p.getSignallist().get(rhIndex).getRt() + rtThresold;
                                 for (int k = rhIndex; k <= rboundIndex; k++)
                                 {
                                     if (p.getSignallist().get(k).getHeight() <= rbInt)
                                     {
                                         rbInt = p.getSignallist().get(k).getHeight();
                                         rbIndex = k;
                                     }
                                     if (p.getSignallist().get(k).getRt() >= rtright)
                                     {
                                         break;
                                     }
                                 }
                                 float rtleft = p.getSignallist().get(lhIndex).getRt() - rtThresold;
                                 for (int k = lhIndex; k >= lboundIndex; k--)
                                 {
                                     if (p.getSignallist().get(k).getHeight() <= lbInt)
                                     {
                                         lbInt = p.getSignallist().get(k).getHeight();
                                         lbIndex = k;
                                     }
                                     if (p.getSignallist().get(k).getRt() <= rtleft)
                                     {
                                         break;
                                     }
                                 }

                                 ds_peak newp = new ds_peak();
                                 newp.getCentralSignal().setMz(s.getMz());
                                 newp.getCentralSignal().setRt(s.getRt());
                                 newp.getCentralSignal().setHeight(s.getHeight());
                                 for (int k = lbIndex; k <= rbIndex; k++)
                                 {
                                     newp.getSignallist().add(p.getSignallist().get(k));
                                     temslist.set(temslist.indexOf(p.getSignallist().get(k)), null);
                                     p.getSignallist().set(k, null);
                                 }

                                 templist.add(newp);
                             }
                             else
                             {
                                 ds_peak newp = new ds_peak();
                                 newp.getCentralSignal().setMz(s.getMz());
                                 newp.getCentralSignal().setRt(s.getRt());
                                 newp.getCentralSignal().setHeight(s.getHeight());
                                 for (int k = lboundIndex; k <= rboundIndex; k++)
                                 {
                                     newp.getSignallist().add(p.getSignallist().get(k));
                                     temslist.set(temslist.indexOf(p.getSignallist().get(k)), null);
                                     p.getSignallist().set(k, null);
                                 }
                                 templist.add(newp);
                             }
                         }
                     }


                     int count = 0;
                     //檢查 peak shape, 每一個peak的相對高度是否有>2倍
                     for (int j = 0; j < templist.size(); j++)
                     {
                         if (templist.get(j).getSignallist().size() >= MinIons)
                         {
                             Collections.sort(templist.get(j).getSignallist(), new ds_signal.RTComparison());
                             float rSN = templist.get(j).getCentralSignal().getHeight() / templist.get(j).getSignallist().get(templist.get(j).getSignallist().size() - 1).getHeight();
                             float lSN = templist.get(j).getCentralSignal().getHeight() / templist.get(j).getSignallist().get(0).getHeight();
                             count += 1;
                         }
                     }

                     //如果split peak中, 大於兩個以上的peak points 數大於 MinIons, 檢查是否為coeluted, 0: Good; 1: Bad
                     if (count >= 2)
                     {
                         for (int j = 0; j < templist.size(); j++)
                         {
                             templist.get(j).setQCoeluted(1);
                         }
                     }

                     for (int j = 0; j < templist.size(); j++)
                     {
                         if ((templist.get(j).getSignallist().size() >= MinIons) && (templist.get(j).getSignallist().size() <= MaxPeakWdith))
                         {
                             newplist.add(templist.get(j));
                         }
                     }
                 }
                 else
                 {
                     //p.qPoint = 1; //點數過少
                     //newplist.Add(p);
                 }
             }


             //清除backIsoDic
             for (int i = 0; i < newplist.size(); i++)
             {
                 ds_peak newp = newplist.get(i);
                 for (int j = 0; j < newp.getSignallist().size(); j++)
                 {
                     ArrayList<Integer> rklist = new ArrayList<Integer>();
                     for (int z : newp.getSignallist().get(j).getBackIsoDic().keySet())
                     {
                         ds_signal s = newp.getSignallist().get(j).getBackIsoDic().get(z);
                         if (s == null)
                         {
                             rklist.add(z);
                         }
                     }
                     for (int k = 0; k < rklist.size(); k++)
                     {
                         newp.getSignallist().get(j).getBackIsoDic().remove(rklist.get(k));
                     }
                 }
             }

             newpcMap.put(MZChannel, newplist);
         }
         allpcMap.clear();

         return newpcMap;
     }

     public final ArrayList<ds_peak> ChargeStateDetermination(TreeMap<Integer, ArrayList<ds_peak>> NewpcMap, double Similarity, int MinIons)
     {
         ArrayList<ds_peak> allplist = new ArrayList<ds_peak>();
         for (ArrayList<ds_peak> plist : NewpcMap.values())
         {
             allplist.addAll(plist);
         }
         Collections.sort(allplist); //由intensity大的開始處理

         ArrayList<ds_peak> rplist = new ArrayList<ds_peak>();
         for (int i = allplist.size() - 1; i >= 0; i--)
         {
             ds_peak p = allplist.get(i);

             //檢查此 peak是否為isotopic peak, 若是則不計算其charge
             boolean isIsopeak = false;
             ArrayList<ds_signal> templist = new ArrayList<ds_signal>();
             templist.addAll(p.getSignallist());
             Collections.sort(templist); //按照intensity排序
             if (templist.get(templist.size() - 1).isIsoSignal())
             {
                 isIsopeak = true;
             }

             if (!isIsopeak)
             {
                 ArrayList<Integer> posClist = new ArrayList<Integer>();
                 //先整理出有多少個 possible charge state, 以 second isotopic peak 為主
                 for (int j = 0; j < p.getSignallist().size(); j++)
                 {
                     ds_signal s = p.getSignallist().get(j);
                     for (int z : s.getBackIsoDic().keySet())
                     {
                         if (!posClist.contains(z))
                         {
                             posClist.add(z);
                         }
                     }
                 }

                 int bestChargeState = 0;
                 //計算 Similarity
                 double bestSimilarity = 0;
                 float maxIntsum = 0;
                 Collections.sort(posClist); //按照 charge 排序, 由charge最大的開始處理
                 for (int j = posClist.size() - 1; j >= 0; j--)
                 {
                     float Intsum = 0;
                     int rtcount = 0; // 紀錄有多少個isotopic signal
                     double avgmzcount = 0; //紀錄平均而言, 一個signal會有幾個isotopic pattern
                     int scount = 0; //用來當作 avgmzcount 的分母
                     double a = 0;
                     double b = 0;
                     double c = 0;

                     for (int k = 0; k < p.getSignallist().size(); k++)
                     {
                         ds_signal s = p.getSignallist().get(k);
                         if (s.getBackIsoDic().containsKey(posClist.get(j)))
                         {
                             ds_signal isp = (ds_signal)s.getBackIsoDic().get(posClist.get(j));
                             if (isp.getHeight() >= 0)
                             {
                                 a += (p.getSignallist().get(k).getHeight() * p.getSignallist().get(k).getHeight());
                                 b += (isp.getHeight() * isp.getHeight());
                                 c += (p.getSignallist().get(k).getHeight() * isp.getHeight());
                                 rtcount += 1;

                                 Intsum += isp.getHeight();

                                 //avgmzcount
                                 boolean flag = true;
                                 scount += 1;
                                 while (flag)
                                 {
                                     avgmzcount += 1;
                                     if (isp.getBackIsoDic().containsKey(posClist.get(j)))
                                     {
                                         isp = isp.getBackIsoDic().get(posClist.get(j));
                                     }
                                     else
                                     {
                                         flag = false;
                                     }
                                 }
                             }
                         }
                     }
                     avgmzcount = (double)avgmzcount / (double)scount;
                     double sim = (double)(c / (Math.sqrt(a) * Math.sqrt(b)));
                     double propotion = (double)rtcount / (double)p.getSignallist().size(); //num of 2nd isotopic peak/ num of 1st isotopic peak

                     if ((sim >= Similarity) && (rtcount >= MinIons)) //1. similarity>=0.8, 2. propotion>=0.4, 3. num of 2nd isotopic peak>=3
                     {
                         sim = ((double)avgmzcount) * ((double)rtcount / (double)p.getSignallist().size()) * sim;

                         if (sim > bestSimilarity)
                         {
                             bestSimilarity = sim;
                             bestChargeState = posClist.get(j);
                             p.setQCharge(0);
                         }
                     }
                     else //intensity決定charge
                     {
                         //bestChargeState = 0;
                         p.setQCharge(1);
                         if (Intsum > maxIntsum)
                         {
                             maxIntsum = Intsum;
                             bestChargeState = posClist.get(j);
                         }
                         else if (Intsum == maxIntsum) //如果相等, 那麼就取charge最小的
                         {
                             if (posClist.get(j).compareTo(bestChargeState) < 0)
                             {
                                 bestChargeState = posClist.get(j);
                             }
                         }
                     }
                 }

                 if (bestChargeState > 0)
                 {
                     p.setCharge(bestChargeState);
                     HashMap<Double, Float> tempDic = new HashMap<Double, Float>();

                     //將此 peak 後的 signal 設定為isotopic signal
                     for (int j = 0; j < p.getSignallist().size(); j++)
                     {
                         ds_signal s = p.getSignallist().get(j);
                         boolean flag = true;
                         ds_signal isbp = s.getBackIsoDic().containsKey(bestChargeState) ? s.getBackIsoDic().get(bestChargeState) : null;
                         if (isbp != null)
                         {
                             while (flag)
                             {
                                 isbp.setIsoSignal(true);

                                 //region Record the m/z and height of isotopic signals
                                 double key = Double.isNaN(isbp.getMz()) ? Double.NaN : Math.round(isbp.getMz() * 100.0) / 100.0;//保留小數點後2位
                                 if (tempDic.containsKey(key))
                                 {
                                     float height = tempDic.get(key);
                                     if (height < isbp.getHeight())
                                     {
                                         tempDic.remove(key);
                                         tempDic.put(key, isbp.getHeight());
                                     }
                                 }
                                 else
                                 {
                                     tempDic.put(key, isbp.getHeight());
                                 }

                                 if (isbp.getBackIsoDic().containsKey(bestChargeState))
                                 {
                                     isbp = isbp.getBackIsoDic().get(bestChargeState);
                                 }
                                 else
                                 {
                                     flag = false;
                                 }
                             }
                         }
                     }

                     for (double key : tempDic.keySet())
                     {
                         p.setIsoStr(p.getIsoStr() + key + "_" + tempDic.get(key) + ";");
                     }

                     Collections.sort(p.getSignallist());

                     //計算 isotopic ratio (因為要依照 intensity 排序, 因此必須最後處理)
                     if (p.getSignallist().size() <= MinIons) //代表 peaks數不多, 則取 average isotopic ratio
                     {
                         float abundA = 0.0f; //1st abundance
                         float abundB = 0.0f; //2nd abundance
                         for (int j = 0; j < p.getSignallist().size(); j++)
                         {
                             ds_signal s = p.getSignallist().get(j);
                             ds_signal isbp = s.getBackIsoDic().containsKey(bestChargeState) ? s.getBackIsoDic().get(bestChargeState) : null;
                             if ((isbp != null) && (isbp.getHeight() > 0))
                             {
                                 abundA += s.getHeight();
                                 abundB += isbp.getHeight();
                             }
                         }
                         if (abundA > 0)
                         {
                             p.setIsoRatio(abundB / abundA);
                         }
                         else
                         {
                             p.setCharge(0); // 證據不足, intensity高的都沒有此 charge, 則是 charge=0.
                         }
                     }
                     else
                     {
                         int button = p.getSignallist().size() - (int)Math.rint((double)(p.getSignallist().size() / 2)); //取 intensity top 50% 的isotopic ratio 平均
                         float abundA = 0.0f; //1st abundance
                         float abundB = 0.0f; //2nd abundance
                         for (int j = p.getSignallist().size() - 1; j >= button; j--)
                         {
                             ds_signal s = p.getSignallist().get(j);
                             ds_signal isbp = s.getBackIsoDic().containsKey(bestChargeState) ? s.getBackIsoDic().get(bestChargeState) : null;
                             if ((isbp != null) && (isbp.getHeight() > 0))
                             {
                                 abundA += s.getHeight();
                                 abundB += isbp.getHeight();
                             }
                         }
                         if (abundA > 0)
                         {
                             p.setIsoRatio(abundB / abundA);
                         }
                         else
                         {
                             p.setCharge(0); // 證據不足, intensity高的都沒有此 charge, 則是 charge=0.
                         }
                     }
                 }
             }
             else //將此 peak 自plist中移除
             {
                 rplist.add(p);
             }
         }
         for (int i = 0; i < rplist.size(); i++)
         {
             allplist.remove(rplist.get(i));
         }

         return allplist;
     }

     public final void PrintResult(String input, String output, ArrayList<ds_peak> allplist)
     {
         String output_txt = output + ".txt";
         try (FileWriter sw = new FileWriter(output_txt))
         {
             sw.write("M/Z" + "\t" + "RT(Sec)" + "\t" + "Start_RT(Sec)" + "\t" + "End_RT(Sec)" + "\t"
                     + "Charge" + "\t" + "Height" + "\t" + "Abundance" + "\t" + "Isotopic Ratio" + "\t"
                     + "NoiseLevel" + "\t" + "ScanNum" + "\t" + "Shapiro-Wilk value" + "\t"
                     + "Slope" + "\t" + "ZigZagIndex" + "\t" + "Symmetry" + "\t" + "Sharpness" + "\t"
                     + "TPASR" + "\t" + "ApexMaxBoundary" + "\t" + "SignificanceLevel" +"\t"+ "SNR" + System.lineSeparator());
                     //+ "TPASR" + "\t" + "ApexMaxBoundary" + "\t" + "SignificanceLevel" +"\t"+ "SNR" + "\t" + "Number of Scans" + System.lineSeparator());

             Collections.sort(allplist, new ds_peak.MZComparison());
             for (int i = 0; i < allplist.size(); i++)
             {
                 ds_peak p = allplist.get(i);

                 Collections.sort(p.getSignallist());
                 int ScanNum = p.getSignallist().get(p.getSignallist().size() - 1).getScanNum();

                 double area = 0;
                 Collections.sort(p.getSignallist(), new ds_signal.RTComparison());
                 //region 計算面積: 積分
                 if (p.getSignallist().size() <= 1)
                 {
                     area = p.getCentralSignal().getHeight();
                 }
                 else
                 {
                     for (int j = 0; j <= p.getSignallist().size(); j++)
                     {
                         if (j == 0)
                         {
                             area += Math.abs(0 + p.getSignallist().get(j).getHeight()) * Math.abs(p.getSignallist().get(0).getRt() - p.getSignallist().get(1).getRt()) * 0.5;
                         }
                         else if (j == p.getSignallist().size())
                         {
                             area += Math.abs(0 + p.getSignallist().get(j - 1).getHeight()) * Math.abs(p.getSignallist().get(j - 1).getRt() - p.getSignallist().get(j - 2).getRt()) * 0.5;
                         }
                         else
                         {
                             area += Math.abs(p.getSignallist().get(j).getHeight() + p.getSignallist().get(j - 1).getHeight()) * Math.abs(p.getSignallist().get(j - 1).getRt() - p.getSignallist().get(j).getRt()) * 0.5;
                         }
                     }
                 }
                 //endregion

                 float noiselevel = 0;
                 //region Noise Level
                 for (int j = 0; j < p.getSignallist().size(); j++)
                 {
                     noiselevel += p.getSignallist().get(j).getNoiselevel();
                 }
                 noiselevel = noiselevel / p.getSignallist().size();

                 //endregion

                 //evaluate peak quality
                 double[] intAry = new double[p._signallist.size()];
                 TreeMap<String, Double> eicMap = new TreeMap<String, Double>();  //eicMap: key=rt (min); value=Intensity
                 for(int j=0; j<p._signallist.size(); j++){
                     ds_signal s = p._signallist.get(j);
                     eicMap.put(String.valueOf(s.getRt()/60), Double.parseDouble(String.valueOf(s.getHeight())));
                     intAry[j] = s.getHeight();
                 }
                 EvaluateQuality eq = new EvaluateQuality();
                 double swt = eq.calculateSW(intAry);
                 double nr = eq.calculateNR(intAry);
                 double slope = eq.calculateSlope(eicMap);
                 double zigzagindex = eq.calculateZigZagIndex(eicMap);
                 double symmetry = eq.calculateSymmetry(eicMap);
                 double sharpness = eq.calculateSharpness(eicMap);
                 double TPASR = eq.calculateTPASR(intAry);
                 double apexboundary = eq.calculateApexMaxBoundary(eicMap);
                 double peaksignificancelevel = eq.calculatePeakSignificanceLevel(eicMap);

                 sw.write(p.getCentralSignal().getMz() + "\t"
                         + p.getCentralSignal().getRt() + "\t"
                         + p.getSignallist().get(0).getRt() + "\t"
                         + p.getSignallist().get(p.getSignallist().size() - 1).getRt() + "\t"
                         + p.getCharge() + "\t"
                         + p.getCentralSignal().getHeight() + "\t"
                         + area + "\t"
                         + p.getIsoRatio() + "\t"
                         + noiselevel + "\t"
                         + ScanNum + "\t"
                         + swt + "\t"
                         + slope + "\t"
                         + zigzagindex + "\t"
                         + symmetry + "\t"
                         + sharpness + "\t"
                         + TPASR + "\t"
                         + apexboundary + "\t"
                         + peaksignificancelevel + "\t"
                         + (p.getCentralSignal().getHeight())/noiselevel + System.lineSeparator());
                         //+ p._signallist.size() + System.lineSeparator());

             }
         } catch (IOException e) {
             e.printStackTrace();
         }
     }

 }