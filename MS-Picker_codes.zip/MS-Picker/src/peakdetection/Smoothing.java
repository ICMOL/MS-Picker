package peakdetection;

import java.util.*;

public class Smoothing {
    public final ArrayList<Float> MovingAverage(ArrayList<Float> IntList, int windowsize) {
        ArrayList<Float> smoothedIntList = new ArrayList<Float>();
        if (IntList == null) {
            return null;
        } else if (IntList.size() <= 1) {
            smoothedIntList.addAll(IntList);
            return smoothedIntList;
        } else {
            ArrayList<Float> tempList = new ArrayList<Float>();

            int extra = (windowsize - 1) / 2;

            //add pre node
            for (int i = 0; i < extra; i++) {
                tempList.add(IntList.get(0));
            }

            //add rawdata
            tempList.addAll(IntList);

            //add post node
            for (int i = 0; i < extra; i++) {
                tempList.add(IntList.get(IntList.size() - 1));
            }

            for (int i = extra; i < tempList.size() - extra; i++) {
                float sumwidth = 0.0f;
                for (int j = (-1 * extra); j <= extra; j++) {
                    sumwidth += tempList.get(i + j);
                }
                float newy = sumwidth / windowsize;
                smoothedIntList.add(newy);
            }

            return smoothedIntList;
        }
    }

    public final ArrayList<Float> SavitzkyGolay(ArrayList<Float> IntList, int filterWidth) {
        ArrayList<Float> smoothedIntList = new ArrayList<Float>();
        if (IntList == null) {
            return null;
        } else if (IntList.size() <= 1) {
            smoothedIntList.addAll(IntList);
            return smoothedIntList;
        } else {
            ArrayList<Float> tempList = new ArrayList<Float>();

            float[][] table = new float[4][];
            table[0] = new float[]{-3, 12, 17, 12, -3};
            table[1] = new float[]{-2, 3, 6, 7, 6, 3, -2};
            table[2] = new float[]{-21, 14, 39, 54, 59, 54, 39, 14, -21};
            table[3] = new float[]{-36, 9, 44, 69, 84, 89, 84, 69, 44, 9, -36};

            int extra = (table[filterWidth].length - 1) / 2;
            float sumOfFilter = 0;
            for (float value : table[filterWidth]) {
                sumOfFilter += value;
            }

            //add pre node
            for (int i = 0; i < extra; i++) {
                tempList.add((float) 0);//本來0
            }

            //add rawdata
            tempList.addAll(IntList);

            //add post node
            for (int i = 0; i < extra; i++) {
                tempList.add((float) 0);//本來0
            }

            for (int i = extra; i < tempList.size() - extra; i++) {
                float sumwidth = 0.0f;
                for (int j = (-1 * extra); j <= extra; j++) {
                    sumwidth += tempList.get(i + j) * table[filterWidth][j + extra];
                }
                float newy = sumwidth / sumOfFilter;
                smoothedIntList.add(newy);
            }

            //Savitzky Golay 可能會有小於0的y
            for (int i = 0; i < smoothedIntList.size(); i++) {
                if (smoothedIntList.get(i).compareTo((float) 0) < 0) {//本來0
                    smoothedIntList.set(i, (float) 0);//本來0
                }
            }
            return smoothedIntList;
        }
    }
}