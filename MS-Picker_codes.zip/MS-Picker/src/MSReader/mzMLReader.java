package MSReader;

import MSDataStructure.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.*;
import java.io.*;

import MSProcessor.*;

import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

//import org.apache.commons.io.FilenameUtils;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.XMLReader;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import javax.xml.stream.*;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class mzMLReader
{
    private int PrecursorScanNum = -1;

    //============================Load full range data============================
    /**
     Load entire data into memory (without centroiding data)

     @param FileName File Name
     @param withPoints with Points

     */
    public final MSRawData ReadmzML(String FileName, boolean withPoints)
    {
        MSRawData raw = new MSRawData();
        raw.setFileName(FileName);
        raw.ScanNumList =new ArrayList<>();//new加
        raw.ScanDic =new HashMap<>();//new加
        int NumberScansToRead = 0;
        int Num = 1; int countnew=0;
        
        //1.獲取sax解析器的工廠物件
        //SAXParserFactory factory = SAXParserFactory.newInstance();
        // 2.通過工廠物件 SAXParser建立解析器物件
        boolean bspectrum = false;//stax parser
        try {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            XMLStreamReader streamReader = factory.createXMLStreamReader(new FileReader(FileName));

            while(streamReader.hasNext()) {
                //streamReader.next();
                int event = streamReader.next();
                if (event == XMLStreamReader.START_ELEMENT ) {
                    countnew++;
                    if (streamReader.getLocalName().equals("spectrumList")) {
                        
                        String count = streamReader.getAttributeValue(null, "count");
                        NumberScansToRead = Integer.parseInt(count);
                    }
                    if (streamReader.getLocalName().equals("spectrum")) {
                        MSScan scan = GetSingleScanFromFile(streamReader, withPoints);
                        scan.setOriginalNum(scan.getNum());
                        scan.setNum(Num);
                        Num += 1;
                        raw.setScanNumList(scan.getOriginalNum());
                        raw.setScanDic(scan.getNum(), scan);
                    }
                }
                }//stax parser
            } catch (XMLStreamException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        FillBlank(raw);
        return raw;
    }

    /**
     Load entire data into memory (without centroiding data)

     @param FileName File Name
     @param withPoints with Points
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, boolean withPoints, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, withPoints);

        ArrayList<Integer> rslist = new ArrayList<Integer>();
        //Scan scan = new MSScan();
        for (MSScan scan : raw.ScanDic.values())
        {
            if (scan.MsLevel != MsLevel)
            {
                rslist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rslist.size(); i++)
        {
            raw.ScanDic.remove(rslist.get(i));
        }

        return raw;
    }

    /**
     Load entire data into memory (without centroiding data)

     @param FileName File Name
     @param withPoints with Points
     @param withCalibration withCalibration

     */
    public final MSRawData ReadmzML(String FileName, boolean withPoints, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, withPoints);

        ArrayList<Integer> rslist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((!withCalibration) && (scan.getScanType().equals("calibration")))
            {
                rslist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rslist.size(); i++)
        {
            raw.ScanDic.remove(rslist.get(i));
        }

        return raw;
    }

    /**
     Load entire data into memory (without centroiding data)

     @param FileName File Name
     @param withPoints with Points
     @param MsLevel MsLevel
     @param withCalibration withCalibration

     */
    public final MSRawData ReadmzML(String FileName, boolean withPoints, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, withPoints);

        ArrayList<Integer> rslist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if (((!withCalibration) && (scan.getScanType().equals("calibration"))) || (scan.MsLevel != MsLevel))
            {
                rslist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rslist.size(); i++)
        {
            raw.ScanDic.remove(rslist.get(i));
        }

        return raw;
    }

    //---------------------------Load full range data (Centriod)---------------------------

    /**
     Load and centroid entire data into memory

     @param FileName File Name
     @param MZWidth MZWidth

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth)
    {
        MSRawData raw = ReadmzML(FileName, true);

        PointsCentroid pc = new PointsCentroid();
        for (MSScan scan : raw.ScanDic.values())
        {
            scan.Points = pc.Centroid(scan.Points, MZWidth);
        }

        return raw;
    }

    /**
     Load and centroid entire data into memory

     @param FileName File Name
     @param MZWidth MZWidth
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel);
        MSPoints t1= new MSPoints();
        PointsCentroid pc = new PointsCentroid();
        for (MSScan scan : raw.ScanDic.values())
        {
            //t1=pc.Centroid(scan.Points, MZWidth);
            //scan.Points = new MSPoints();
            scan.setPoints(pc.Centroid(scan.Points, MZWidth));
        }
        return raw;
    }

    /**
     Load and centroid entire data into memory

     @param FileName File Name
     @param MZWidth MZWidth

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, withCalibration);

        PointsCentroid pc = new PointsCentroid();
        for (MSScan scan : raw.ScanDic.values())
        {
            scan.Points = pc.Centroid(scan.Points, MZWidth);
        }

        return raw;
    }

    /**
     Load and centroid entire data into memory

     @param FileName File Name
     @param MZWidth MZWidth
     @param MsLevel MsLevel
     @param MsLevel withCalibration

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel, withCalibration);

        PointsCentroid pc = new PointsCentroid();
        for (MSScan scan : raw.ScanDic.values())
        {
            scan.Points = pc.Centroid(scan.Points, MZWidth);
        }

        return raw;
    }

    //============================Load subset data (mz)============================
    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ)
    {
        MSRawData raw = ReadmzML(FileName, true);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, withCalibration);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel, withCalibration);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    //---------------------------Load full range data (Centriod)(mz)---------------------------
    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, withCalibration);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel, withCalibration);

        for (MSScan scan : raw.ScanDic.values())
        {
            ArrayList<Double> mzlist = new ArrayList<Double>();
            ArrayList<Float> heightlist = new ArrayList<Float>();
            for (int j = 0; j < scan.Points.mzList.size(); j++)
            {
                if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                {
                    double mz = scan.Points.mzList.get(j);
                    float height = scan.Points.heightList.get(j);
                    mzlist.add(mz);
                    heightlist.add(height);
                }
            }
            scan.Points.mzList.clear();
            scan.Points.heightList.clear();
            scan.Points.mzList.addAll(mzlist);
            scan.Points.heightList.addAll(heightlist);
        }

        return raw;
    }

    //============================Load subset data (rt)============================
    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, float minRT, float maxRT)
    {
        MSRawData raw = ReadmzML(FileName, true);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, float minRT, float maxRT, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, float minRT, float maxRT, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, float minRT, float maxRT, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    //---------------------------Load full range data (Centriod)(rt)---------------------------
    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, float MZWidth, float minRT, float maxRT)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, float minRT, float maxRT, int MsLevel)//loadin
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, float minRT, float maxRT, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel
     @param withCalibration withCalibration

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, float minRT, float maxRT, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime < minRT) || (scan.RetentionTime > maxRT))
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    //============================Load subset data (mz+rt)============================
    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, float minRT, float maxRT)
    {
        MSRawData raw = ReadmzML(FileName, true);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, float minRT, float maxRT, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, float minRT, float maxRT, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param (FileName) File Name
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel
     @param withCalibration withCalibration

     */
    public final MSRawData ReadmzML(String FileName, double minMZ, double maxMZ, float minRT, float maxRT, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, true, MsLevel, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    //---------------------------Load full range data (Centriod)(mz+rt)---------------------------
    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, float minRT, float maxRT)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName  FileName
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, float minRT, float maxRT, int MsLevel)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, float minRT, float maxRT, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    /**
     Dynamically access partial data region in a given m/z and retention time range (without centroiding data)

     @param FileName File Name
     @param MZWidth MZWidth
     @param minMZ minMZ
     @param maxMZ maxMZ
     @param minRT minRT (unit: sec.)
     @param maxRT maxRT (unit: sec.)
     @param MsLevel MsLevel
     @param withCalibration withCalibration

     */
    public final MSRawData ReadmzML(String FileName, double MZWidth, double minMZ, double maxMZ, float minRT, float maxRT, int MsLevel, boolean withCalibration)
    {
        MSRawData raw = ReadmzML(FileName, MZWidth, MsLevel, withCalibration);

        ArrayList<Integer> rlist = new ArrayList<Integer>();
        for (MSScan scan : raw.ScanDic.values())
        {
            if ((scan.RetentionTime >= minRT) && (scan.RetentionTime <= maxRT))
            {
                ArrayList<Double> mzlist = new ArrayList<Double>();
                ArrayList<Float> heightlist = new ArrayList<Float>();
                for (int j = 0; j < scan.Points.mzList.size(); j++)
                {
                    if ((scan.Points.mzList.get(j).compareTo(minMZ) >= 0) && (scan.Points.mzList.get(j).compareTo(maxMZ) <= 0))
                    {
                        double mz = scan.Points.mzList.get(j);
                        float height = scan.Points.heightList.get(j);
                        mzlist.add(mz);
                        heightlist.add(height);
                    }
                }
                scan.Points.mzList.clear();
                scan.Points.heightList.clear();
                scan.Points.mzList.addAll(mzlist);
                scan.Points.heightList.addAll(heightlist);
            }
            else
            {
                rlist.add(scan.getNum());
            }
        }
        for (int i = 0; i < rlist.size(); i++)
        {
            raw.ScanDic.remove(rlist.get(i));
        }

        return raw;
    }

    //=========================================================================================
    private void FillBlank(MSRawData raw)
    {
        raw.rtDi=new HashMap<>();
        for (MSScan scan : raw.ScanDic.values())
        {
            //Record the number of individual mslevel
            if (scan.MsLevel == 1)
            {
                raw.NumScanLevel1 += 1;
            }
            else if (scan.MsLevel == 2)
            {
                raw.NumScanLevel2 += 1;
            }

            //Check GlobalMinMZ, GlobalMaxMZ
            if (scan.getLowMZ() < raw.GlobalLowMZ)
            {
                raw.GlobalLowMZ = scan.getLowMZ();
            }
            if (scan.getHighMZ() > raw.GlobalHighMZ)
            {
                raw.GlobalHighMZ = scan.getHighMZ();
            }

            //Generate rt vs. scanNumber matching
            int rt = Integer.parseInt(String.valueOf(Math.round(scan.RetentionTime)));
            //int rt = Integer.parseInt(String.valueOf(Double.isNaN(scan.RetentionTime) ? Double.NaN : Math.round(scan.RetentionTime * Math.pow(10, 0)) / Math.pow(10, 0)));
            if (!raw.rtDi.containsKey(rt))
            {
                ArrayList<Integer> ScanNumlist = new ArrayList<Integer>();
                ScanNumlist.add(scan.getNum());
                raw.rtDi.put(rt, ScanNumlist);
            }
            else
            {
                ArrayList<Integer> ScanNumlist = raw.getRtDi().get(rt);
                ScanNumlist.add(scan.getNum());
            }
        }
    }
    private MSScan GetSingleScanFromFile(XMLStreamReader reader, boolean withPoints)
    {
        MSScan scan = new MSScan();
        int counttest=0;
        try {//stax parser
                    if (reader.getLocalName().equals("spectrum")) {
                        counttest++;
                        String id = reader.getAttributeValue(null, "id");
                        scan.setScanType(id);
                        String index = reader.getAttributeValue(null, "index");

                        scan.setNum(Integer.parseInt(index) + 1); //Because the scan number start from 0 in the raw file.
                        GetRootInfo(scan, reader);
                        scan.MsLevel = 1;
                        if (reader.getLocalName().equals("scanList")) {
                            scan.RetentionTime = GetElutionTime(reader);
                        }
                        if (reader.getLocalName().equals("precursorList")) {
                            GetPrecursor(scan, reader);
                            scan.setPrecursorScanNum(PrecursorScanNum);
                        } else {
                            PrecursorScanNum = scan.getNum();
                        }
                        if (reader.getLocalName().equals("binaryDataArrayList") && withPoints) {
                            scan.Points = GetPeak(reader);
                            if (!scan.Points.mzList.isEmpty()) {
                                scan.setLowMZ(scan.Points.mzList.get(0));
                                scan.setHighMZ(scan.Points.mzList.get(scan.Points.mzList.size() - 1));

                                if (scan.getBasePeakIntensity() <= 0) {//The basepeak is not recorded.
                                    int index2 = 0;
                                    float tempHeight = 0;
                                    for (int i = 0; i < scan.Points.mzList.size(); i++) {
                                        if (scan.Points.heightList.get(i).compareTo(tempHeight) >= 0) {
                                            tempHeight = scan.Points.heightList.get(i);
                                            index2 = i;
                                        }
                                    }
                                    scan.setBasePeakMZ(scan.Points.mzList.get(index2));
                                    scan.setBasePeakIntensity(scan.Points.heightList.get(index2));
                                }
                            }
                        }
                    }
        } catch (XMLStreamException | DataFormatException | UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scan;
    }
    private void GetRootInfo(MSScan scan, XMLStreamReader reader) throws XMLStreamException {
        while (reader.hasNext())
        {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("cvParam"))
            {
                String name = reader.getAttributeValue(null, "name");
                switch (name)
                {
                    case "total ion current":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.setTotalIonCurrent(Float.parseFloat(value));
                        break;
                    }
                    case "ms level":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.MsLevel = Integer.parseInt(value);
                        break;
                    }
                    case "lowest observed m/z":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.setLowMZ(Float.parseFloat(value));
                        break;
                    }
                    case "highest observed m/z":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.setHighMZ(Float.parseFloat(value));
                        break;
                    }
                    case "base peak m/z":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.setBasePeakMZ(Float.parseFloat(value));
                        break;
                    }
                    case "base peak intensity":
                    {
                        String value = reader.getAttributeValue(null, "value");
                        scan.setBasePeakIntensity(Float.parseFloat(value));
                        break;
                    }
                }
            }
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("scanList"))
            {
                break;
            }
        }
    }
    private float GetElutionTime(XMLStreamReader reader) throws XMLStreamException {
        float rt = 0f;
        while (reader.hasNext())
        {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("scan"))
            {
                while (reader.hasNext())
                {
                    int event2 = reader.next();
                    if (event2 == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("cvParam"))
                    {
                        String name = reader.getAttributeValue(null, "name");
                        if (name.equals("scan start time"))
                        {
                            String value = reader.getAttributeValue(null, "value");
                            float tempRT = Float.parseFloat(value);
                            String unitName = reader.getAttributeValue(null, "unitName");
                            if (unitName.equals("minute"))
                            {
                                rt = tempRT * 60;
                            }
                            else
                            {
                                rt = tempRT;
                            }
                        }
                    }
                    else if (reader.getEventType() == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("scan"))
                    {
                        break;
                    }
                }
            }
            if (event == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("scanList"))
            {
                reader.next();
                reader.next();
                break;
            }
        }
        return rt;
    }
    private void GetPrecursor(MSScan scan, XMLStreamReader reader) throws XMLStreamException {
        scan.MsLevel = 1;
        while (reader.hasNext())
        {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("precursor"))
            {
                scan.MsLevel = 2;
                while (reader.hasNext())
                {
                    int event2 = reader.next();
                    if (event2 == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("selectedIon"))
                    {
                        while (reader.hasNext())
                        {
                            int event3 = reader.next();
                            if (event3 == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("cvParam"))
                            {
                                String name = reader.getAttributeValue(null, "name");
                                switch (name)
                                {
                                    case "selected ion m/z":
                                    {
                                        String value = reader.getAttributeValue(null, "value");
                                        scan.setPrecursorMZ(Float.parseFloat(value));
                                        break;
                                    }
                                    case "charge state":
                                    {
                                        String value = reader.getAttributeValue(null, "value");
                                        scan.setPrecursorCharge(Integer.parseInt(value));
                                        break;
                                    }
                                    case "peak intensity":
                                    {
                                        String value = reader.getAttributeValue(null, "value");
                                        scan.setPrecursorIntensity(Float.parseFloat(value));
                                        break;
                                    }
                                }
                            }
                            if (event3 == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("selectedIon"))
                            {
                                break;
                            }
                        }
                    }
                    if (event2 == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("activation"))
                    {
                        while (reader.hasNext())
                        {
                            int event4 = reader.next();
                            if (event4 == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("cvParam"))
                            {
                                String name = reader.getAttributeValue(null, "name");
                                if (name.equals("collision-induced dissociation"))
                                {
                                    scan.setActivationMethod("CID");
                                }
                                break;
                            }
                        }
                    }
                    if (event2 == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("precursor"))
                    {
                        break;
                    }
                }
            }

            else if (event == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("precursorList"))
            {
                reader.next();
                reader.next();
                break;
            }
        }
    }
    private MSPoints GetPeak(XMLStreamReader reader) throws Exception {
        EncodeBit mzbit = EncodeBit.Float32bit;
        EncodeBit intensitybit = EncodeBit.Float32bit;
        boolean mzcompressed = false;
        boolean intensitycompressed = false;
        String mzspeaktring = "";
        String intensitypeakstring = "";

        String type = "";
        String bitinfo = "";
        String compressioninfo = "";
        String peakstring = "";

        while (reader.hasNext())
        {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("binaryDataArray"))
            {
                type = "";
                bitinfo = "";
                compressioninfo = "";
                peakstring = "";
            }
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("cvParam"))
            {
                String name = reader.getAttributeValue(null, "name");
                switch (name)
                {
                    case "m/z array":
                    {
                        type = name;
                        break;
                    }
                    case "intensity array":
                    {
                        type = name;
                        break;
                    }
                    case "64-bit float":
                    {
                        bitinfo = name;
                        break;
                    }
                    case "32-bit float":
                    {
                        bitinfo = name;
                        break;
                    }
                    case "no compression":
                    {
                        compressioninfo = name;
                        break;
                    }
                    case "zlib compression":
                    {
                        compressioninfo = name;
                        break;
                    }
                }
            }
            if (event == XMLStreamConstants.START_ELEMENT && reader.getLocalName().equals("binary"))
            {
                peakstring = reader.getElementText();
            }
            if (event == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("binaryDataArray"))
            {
                if (type.equals("m/z array"))
                {
                    if (compressioninfo.equals("zlib compression"))
                    {
                        mzcompressed = true;
                    }
                    else if (compressioninfo.equals("no compression"))
                    {
                        mzcompressed = false;
                    }

                    if (bitinfo.equals("32-bit float"))
                    {
                        mzbit = EncodeBit.Float32bit;
                    }
                    else if (bitinfo.equals("64-bit float"))
                    {
                        mzbit = EncodeBit.Float64bit;
                    }
                    mzspeaktring = peakstring;
                }

                else if (type.equals("intensity array"))
                {
                    if (compressioninfo.equals("zlib compression"))
                    {
                        intensitycompressed = true;
                    }
                    else if (compressioninfo.equals("no compression"))
                    {
                        intensitycompressed = false;
                    }

                    if (bitinfo.equals("32-bit float"))
                    {
                        intensitybit = EncodeBit.Float32bit;
                    }
                    else if (bitinfo.equals("64-bit float"))
                    {
                        intensitybit = EncodeBit.Float64bit;
                    }
                    intensitypeakstring = peakstring;
                }
            }
            if (event == XMLStreamReader.END_ELEMENT && reader.getLocalName().equals("binaryDataArrayList"))
            {
                break;
            }
        }
        MSPoints Points = ParsePeakNodeMZML(mzspeaktring, intensitypeakstring, mzcompressed, intensitycompressed, mzbit, intensitybit);
        return Points;
    }
    private enum EncodeBit
    {
        Float32bit,
        Float64bit;

        public static final int SIZE = java.lang.Integer.SIZE;

        public int getValue()
        {
            return this.ordinal();
        }

        public static EncodeBit forValue(int value)
        {
            return values()[value];
        }
    }
    private MSPoints ParsePeakNodeMZML(String mzstring, String intensitystring, boolean compressedMZ, boolean compressedIntensity, EncodeBit mzbit, EncodeBit intensitybit) throws Exception {
        byte[] decodedmz = new byte[0];
        byte[] decodedintensity = new byte[0];
        int nobytemz = 4;
        int nobyteintensity = 4;

        if (mzbit == EncodeBit.Float64bit)
        {
            nobytemz = 8;
        }
        if (intensitybit == EncodeBit.Float64bit)
        {
            nobyteintensity = 8;
        }

        if (!compressedMZ)
        {// Base64解碼
            decodedmz = mzstring.length()>0? FromBase64String(mzstring) : new byte[0];
        }
        else
        {
            decodedmz = mzstring.length()>0? BitConverter(mzstring) : new byte[0];//ZlibUncompressBuffer(
        }
        if (!compressedIntensity)
        {// Base64解碼
            decodedintensity = intensitystring.length()>0? FromBase64String(intensitystring) : new byte[0];
        }
        else
        {
            decodedintensity = intensitystring.length()>0? BitConverter(intensitystring) : new byte[0];
        }

        MSPoints Points = new MSPoints();
        Points.mzList=new ArrayList<>();//也可以在mSpoint new
        Points.heightList=new ArrayList<>();
        for (int i = 0; i < decodedmz.length / nobytemz; i++)
        {
            double mz = 0f;
            float intensity = 0f;
            if (mzbit == EncodeBit.Float64bit)
            {
                mz = (float)BitConverter.toDouble(decodedmz, i * nobytemz);
            }
            else if (mzbit == EncodeBit.Float32bit)
            {
                mz = BitConverter.toFloat(decodedmz, i * nobytemz);//toSingle
            }

            if (intensitybit == EncodeBit.Float64bit)
            {
                intensity = (float)BitConverter.toDouble(decodedintensity, i * nobyteintensity);
            }
            else if (intensitybit == EncodeBit.Float32bit)
            {
                intensity = BitConverter.toFloat(decodedintensity, i * nobyteintensity);//toSingle
            }

            Points.mzList.add((double)mz);
            Points.heightList.add(intensity);
        }
        return Points;
    }

    protected final byte[] ZlibUncompressBuffer(String inputstring) throws DataFormatException, UnsupportedEncodingException {
        byte[] compressed = Converter(inputstring);
        return ZlibStream_java.compress(compressed);
    }

    private byte[] BitConverter(String mzstring) throws UnsupportedEncodingException, DataFormatException {
        //宣告
        byte[] decodedmz= new byte[0];
        /**
         * STEP 1: Decode bytes from base-64. These are compressed.
         */
        Base64.Decoder decoder = Base64.getDecoder();
        decodedmz=decoder.decode(mzstring);
        /**
         * STEP 2: Make litte-endian
         */
        {
            ByteBuffer bbuf = ByteBuffer.allocate(decodedmz.length);
            bbuf.put(decodedmz);
            decodedmz = bbuf.order(ByteOrder.LITTLE_ENDIAN).array();
        }
        /**
         * STEP 3: Decompress from zlib. Note the data might not be compressed. Check associated cvParam elements.
         */
        byte[] decompressedData = null;
        {
            Inflater decompressor = new Inflater();
            decompressor.setInput(decodedmz);

            // Create an expandable byte array to hold the decompressed data
            ByteArrayOutputStream bos = null;

            try {

                bos = new ByteArrayOutputStream(decodedmz.length);
                int count2 = 0;
                // Decompress the data
                byte[] buf = new byte[1024];
                while (!decompressor.finished()) {
                    int count = decompressor.inflate(buf);
                    bos.write(buf, 0, count);
                    count2++;
                }
            } finally {
                try {
                    bos.close();
                } catch (Exception nope) { /* This exception doesn't matter */ }
            }

            decompressedData = bos.toByteArray();
        }
        return decompressedData;
    }
    private static float[] getFloatArrayFromCompressedBase64String(String mzstring, byte[] decodedmz) throws Exception {

        /**
         * STEP 1: Decode bytes from base-64. These are compressed.
         */
        Base64.Decoder decoder = Base64.getDecoder();
        decodedmz=decoder.decode(mzstring);

        /**
         * STEP 2: Make litte-endian
         */
        {
            ByteBuffer bbuf = ByteBuffer.allocate(decodedmz.length);
            bbuf.put(decodedmz);
            decodedmz = bbuf.order(ByteOrder.LITTLE_ENDIAN).array();
        }

        /**
         * STEP 3: Decompress from zlib. Note the data might not be compressed. Check associated cvParam elements.
         */
        byte[] decompressedData = null;
        {
            Inflater decompressor = new Inflater();
            decompressor.setInput(decodedmz);

            // Create an expandable byte array to hold the decompressed data
            ByteArrayOutputStream bos = null;

            try {

                bos = new ByteArrayOutputStream(decodedmz.length);

                // Decompress the data
                byte[] buf = new byte[1024];
                while (!decompressor.finished()) {
                    int count = decompressor.inflate(buf);
                    bos.write(buf, 0, count);
                }

            } finally {
                try {
                    bos.close();
                } catch (Exception nope) { /* This exception doesn't matter */ }
            }

            decompressedData = bos.toByteArray();
        }

        /**
         * STEP 4: Read floats from IEEE 754 floating-point "single format" representations
         */
        final int totalFloats = decompressedData.length / 4;
        float[] floatValues = new float[totalFloats];

        // Iterate until parse each float
        int floatIndex = 0;
        for (int nextFloatPosition = 0; nextFloatPosition < decompressedData.length; nextFloatPosition += 4) {
            // Read in the bytes
            char c1 = (char) decompressedData[nextFloatPosition + 0];
            char c2 = (char) decompressedData[nextFloatPosition + 1];
            char c3 = (char) decompressedData[nextFloatPosition + 2];
            char c4 = (char) decompressedData[nextFloatPosition + 3];

            // Bitwise AND to make sure only first 2 bytes are included
            int b1 = (int) (c1 & 0xFF);
            int b2 = (int) (c2 & 0xFF);
            int b3 = (int) (c3 & 0xFF);
            int b4 = (int) (c4 & 0xFF);

            // Build the four-byte floating-point "single  format" representation
            int intBits = (b4 << 0) | (b3 << 8) | (b2 << 16) | (b1 << 24);

            floatValues[floatIndex] = Float.intBitsToFloat(intBits);

            // Increment counter used to populate array
            floatIndex++;
        }

        return floatValues;
    }
    protected byte[] FromBase64String(String inputstring) {
        /**從 base-64 解碼字節。這些是壓縮的。*/
        byte[] binArray = Base64.getDecoder().decode(inputstring);

        ByteBuffer bbuf = ByteBuffer.allocate(binArray.length);
        bbuf.put(binArray);
        binArray = bbuf.order(ByteOrder.LITTLE_ENDIAN).array();

        return binArray;
    }

    private byte[] Converter(String mzstring) throws UnsupportedEncodingException, DataFormatException {
        //宣告
        /**
         * STEP 1: Decode bytes from base-64. These are compressed.
         */
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decoded=decoder.decode(mzstring);
        /**
         * STEP 2: Make litte-endian
         */
        {
            ByteBuffer bbuf = ByteBuffer.allocate(decoded.length);
            bbuf.put(decoded);
            decoded = bbuf.order(ByteOrder.LITTLE_ENDIAN).array();
        }
        /**
         * STEP 3: Decompress from zlib. Note the data might not be compressed. Check associated cvParam elements.
         */
        byte[] decompressedData = null;
        {
            Inflater decompressor = new Inflater();
            decompressor.setInput(decoded);

            // Create an expandable byte array to hold the decompressed data
            ByteArrayOutputStream bos = null;

            try {

                bos = new ByteArrayOutputStream(decoded.length);
                int count2 = 0;
                // Decompress the data
                byte[] buf = new byte[1024];
                while (!decompressor.finished()) {
                    int count = decompressor.inflate(buf);
                    bos.write(buf, 0, count);
                    count2++;
                }
            } finally {
                try {
                    bos.close();
                } catch (Exception nope) { /* This exception doesn't matter */ }
            }

            decompressedData = bos.toByteArray();
        }
        return decompressedData;
    }

    private float[] Converter(byte[] decompressedData) throws UnsupportedEncodingException, DataFormatException {
        /**
         * STEP 4: Read floats from IEEE 754 floating-point "single format" representations
         */
        final int totalFloats = decompressedData.length / 4;
        float[] floatValues = new float[totalFloats];

        // Iterate until parse each float
        int floatIndex = 0;
        for (int nextFloatPosition = 0; nextFloatPosition < decompressedData.length; nextFloatPosition += 4) {
            // Read in the bytes
            char c1 = (char) decompressedData[nextFloatPosition + 0];
            char c2 = (char) decompressedData[nextFloatPosition + 1];
            char c3 = (char) decompressedData[nextFloatPosition + 2];
            char c4 = (char) decompressedData[nextFloatPosition + 3];

            // Bitwise AND to make sure only first 2 bytes are included
            int b1 = (int) (c1 & 0xFF);
            int b2 = (int) (c2 & 0xFF);
            int b3 = (int) (c3 & 0xFF);
            int b4 = (int) (c4 & 0xFF);

            // Build the four-byte floating-point "single  format" representation
            int intBits = (b4 << 0) | (b3 << 8) | (b2 << 16) | (b1 << 24);

            floatValues[floatIndex] = Float.intBitsToFloat(intBits);

            // Increment counter used to populate array
            floatIndex++;
        }

        return floatValues;
    }
}
    class BitConverter {
        public static byte[] getBytes(boolean x) {
            byte[] bytes = new byte[1];
            bytes[0] = (byte) (x ? 1 : 0);
            return bytes;
        }

        public static byte[] getBytes(char c) {
            byte[] bytes = new byte[2];
            if(isLittleEndian()){
                bytes[0] =(byte) (c);
                bytes[1] =(byte) (c>> 8);
            }
            else {
                bytes[1] = (byte) (c);
                bytes[0] = (byte) (c >> 8);
            }
            return bytes;
        }

        public static byte[] getBytes(double x) {
            return getBytes(Double.doubleToLongBits(x));
        }

        public static byte[] getBytes(short x) {
            byte[] bytes = new byte[2];
            if(isLittleEndian()){
                bytes[0] =(byte) (x & 0xff);
                bytes[1] =(byte) ((x & 0xff00)>> 8);
            }
            else {
                bytes[1] =(byte) (x & 0xff);
                bytes[0] =(byte) ((x & 0xff00)>> 8);
            }
            return bytes;
        }

        public static byte[] getBytes(int x) {
            byte[] bytes = new byte[4];
            if(isLittleEndian()){
                bytes[0] =(byte) (x & 0xff);
                bytes[1] =(byte) ((x & 0xff00)>> 8);
                bytes[2] =(byte) ((x & 0xff0000)>> 16);
                bytes[3] =(byte) ((x & 0xff000000)>> 24);
            }
            else {
                bytes[3] =(byte) (x & 0xff);
                bytes[2] =(byte) ((x & 0xff00)>> 8);
                bytes[1] =(byte) ((x & 0xff0000)>> 16);
                bytes[0] =(byte) ((x & 0xff000000)>> 24);
            }
            return bytes;
        }

        public static byte[] getBytes(long x) {
            byte[] bytes = new byte[8];
            if(isLittleEndian()){
                bytes[0] =(byte) (x & 0xff);
                bytes[1] =(byte) ((x >> 8 )& 0xff);
                bytes[2] =(byte) ((x >> 16 )& 0xff);
                bytes[3] =(byte) ((x >> 24 )& 0xff);
                bytes[4] =(byte) ((x >> 32 )& 0xff);
                bytes[5] =(byte) ((x >> 40 )& 0xff);
                bytes[6] =(byte) ((x >> 48 )& 0xff);
                bytes[7] =(byte) ((x >> 56 )& 0xff);
            }
            else {
                bytes[7] =(byte) (x & 0xff);
                bytes[6] =(byte) ((x >> 8 )& 0xff);
                bytes[5] =(byte) ((x >> 16 )& 0xff);
                bytes[4] =(byte) ((x >> 24 )& 0xff);
                bytes[3] =(byte) ((x >> 32 )& 0xff);
                bytes[2] =(byte) ((x >> 40 )& 0xff);
                bytes[1] =(byte) ((x >> 48 )& 0xff);
                bytes[0] =(byte) ((x >> 56 )& 0xff);
            }
            return bytes;
        }

        public static byte[] getBytes(float x) {
            return getBytes(Float.floatToIntBits(x));
        }

        public static byte[] getBytes(String x) {
            return x.getBytes(Charset.forName("UTF-8"));
        }

        public static boolean toBoolean(byte[] bytes) {
            return bytes[0]==0 ? false :true;
        }
        public static long doubleToInt64Bits(double x) {
            return Double.doubleToLongBits(x);
        }

        public static double int64BitsToDouble(long x) {
            return (double) x;
        }

        public boolean toBoolean(byte[] bytes, int index) throws Exception {
            return toBoolean(copyFrom(bytes,index,1));
        }

        public static short toShort(byte[] bytes) throws Exception {
            if(isLittleEndian()){
                return (short)((0xff & bytes[0])| (0xff00 & (bytes[1] << 8)));
            }
            else {
                return (short) ((0xff & bytes[1]) | (0xff00 & (bytes[0] << 8)));
            }
        }

        public static short toShort(byte[] bytes, int index) throws Exception {
            return toShort(copyFrom(bytes,index,2));
        }

        public static char toChar(byte[] bytes) throws Exception {
            if(isLittleEndian()){
                return (char)((0xff & bytes[0])| (0xff00 & (bytes[1] << 8)));
            }
            else {
                return (char) ((0xff & bytes[1]) | (0xff00 & (bytes[0] << 8)));
            }
        }

        public static char toChar(byte[] bytes, int index) throws Exception {
            return toChar(copyFrom(bytes,index,2));
        }

        public static int toInt(byte[] bytes) throws Exception {
            if(isLittleEndian()){
                return ((0xff & bytes[0])| (0xff00 & (bytes[1] << 8)) | (0xff0000 & (bytes[2] << 16)) | (0xff000000 & (bytes[3] << 24)));
            }
            else {
                return ((0xff & bytes[3]) | (0xff00 & (bytes[2] << 8))| (0xff0000 & (bytes[1] << 16)) | (0xff000000 & (bytes[0] << 24)));
            }
        }

        public static int toInt(byte[] bytes, int index) throws Exception {
            return toInt(copyFrom(bytes,index,4));
        }

        public static long toLong(byte[] bytes) throws Exception {
            if(isLittleEndian()){
                return (0xffL & (long)bytes[0])
                        | (0xff00L & ((long)bytes[1] << 8))
                        | (0xff0000L & ((long)bytes[2] << 16))
                        | (0xff000000L & ((long)bytes[3] << 24))
                        | (0xff00000000L & ((long)bytes[4] << 32))
                        | (0xff0000000000L & ((long)bytes[5] << 40))
                        | (0xff000000000000L & ((long)bytes[6] << 48))
                        | (0xff00000000000000L & ((long)bytes[7] << 56));
            }
            else {
                return (0xffL & (long)bytes[7])
                        | (0xff00L & ((long)bytes[6] << 8))
                        | (0xff0000L & ((long)bytes[5] << 16))
                        | (0xff000000L & ((long)bytes[4] << 24))
                        | (0xff00000000L & ((long)bytes[3] << 32))
                        | (0xff0000000000L & ((long)bytes[2] << 40))
                        | (0xff000000000000L & ((long)bytes[1] << 48))
                        | (0xff00000000000000L & ((long)bytes[0] << 56));
            }
        }

        public static long toLong(byte[] bytes, int index) throws Exception {
            return toLong(copyFrom(bytes,index,8));
        }

        public static float toFloat(byte[] bytes) throws Exception {
            return Float.intBitsToFloat(toInt(bytes));
        }

        public static float toFloat(byte[] bytes, int index) throws Exception {
            return Float.intBitsToFloat(toInt(copyFrom(bytes,index,4)));
        }

        public static double toDouble(byte[] bytes) throws Exception {
            return Double.longBitsToDouble(toLong(bytes));
        }

        public static double toDouble(byte[] bytes, int index) throws Exception {
            return Double.longBitsToDouble(toLong(copyFrom(bytes,index,8)));
        }

        public static short toInt16(byte[] bytes, int index) throws Exception {
            if (bytes.length != 8)
                throw new Exception(
                        "The length of the byte array must be at least 8 bytes long.");
            return (short) ((0xff & bytes[index]) << 8 | (0xff & bytes[index + 1]) << 0);
        }

        public static int toInt32(byte[] bytes, int index) throws Exception {
            if (bytes.length != 4)
                throw new Exception(
                        "The length of the byte array must be at least 4 bytes long.");
            return (int) ((int) (0xff & bytes[index]) << 56
                    | (int) (0xff & bytes[index + 1]) << 48
                    | (int) (0xff & bytes[index + 2]) << 40 | (int) (0xff & bytes[index + 3]) << 32);
        }

        public static long toInt64(byte[] bytes, int index) throws Exception {
            if (bytes.length <= 8)
                throw new Exception(
                        "The length of the byte array must be at least 8 bytes long.");
            return (long) ((long) (0xff & bytes[index]) << 56
                    | (long) (0xff & bytes[index + 1]) << 48
                    | (long) (0xff & bytes[index + 2]) << 40
                    | (long) (0xff & bytes[index + 3]) << 32
                    | (long) (0xff & bytes[index + 4]) << 24
                    | (long) (0xff & bytes[index + 5]) << 16
                    | (long) (0xff & bytes[index + 6]) << 8 | (long) (0xff & bytes[index + 7]) << 0);
        }

        public static float toSingle(byte[] bytes, int index) throws Exception {
            if (bytes.length != 4)
                throw new Exception(
                        "The length of the byte array must be at least 4 bytes long.");
            return Float.intBitsToFloat(toInt32(bytes, index));
        }

        public static String toString(byte[] bytes) throws Exception {
            return new String(bytes,Charset.forName("UTF-8"));
        }

        public static String toString(byte[] bytes,String charsetName) throws Exception {
            return new String(bytes,Charset.forName(charsetName));
        }

        public static String toHexString(byte[] bytes) throws Exception {
            if (bytes == null) //throw new Exception("The byte array must have at least 1 byte.")
                return "null";
            int iMax =  bytes.length - 1;
            if(iMax == -1)
                return "[]";
            StringBuilder b =  new StringBuilder();
            b.append('[');
            for(int i = 0; ; i++){
                b.append(String.format("%02x",bytes[i] & 0xff));
                if (i == iMax)
                    return b.append(']').toString();
                b.append(", ");
            }
        }


        private static byte[] copyFrom(byte[] src, int off, int len){
            byte[] bits = new byte[len];
            for(int i = off,j=0;i< src.length && j < len; i++,j++){
                bits[j] = src[i];
            }
            return bits;
        }
        private static boolean isLittleEndian(){
            return ByteOrder.nativeOrder() ==ByteOrder.LITTLE_ENDIAN;
        }
    }
