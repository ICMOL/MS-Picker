package MSReader;

public class ScanPaser
{
    // java Unsigned integer types可能和c#不同
//
    private byte[] _source = null;
    //
    private static byte[] NAME_num = {110, 117, 109};
    //
    private static byte[] NAME_msLevel = {109, 115, 76, 101, 118, 101, 108};
    //
    private static byte[] NAME_peaksCount = {112, 101, 97, 107, 115, 67, 111, 117, 110, 116};
    //
    private static byte[] NAME_polarity = {112, 111, 108, 97, 114, 105, 116, 121};
    //
    private static byte[] NAME_scanType = {115, 99, 97, 110, 84, 121, 112, 101};
    //
    private static byte[] NAME_filterLine = {102, 105, 108, 116, 101, 114, 76, 105, 110, 101};
    //
    private static byte[] NAME_retentionTime = {114, 101, 116, 101, 110, 116, 105, 111, 110, 84, 105, 109, 101};
    //
    private static byte[] NAME_lowMz = {108, 111, 119, 77, 122};
    //
    private static byte[] NAME_highMz = {104, 105, 103, 104, 77, 122};
    //
    private static byte[] NAME_basePeakMz = {98, 97, 115, 101, 80, 101, 97, 107, 77, 122};
    //
    private static byte[] NAME_basePeakIntensity = {98, 97, 115, 101, 80, 101, 97, 107, 73, 110, 116, 101, 110, 115, 105, 116, 121};
    //
    private static byte[] NAME_totIonCurrent = {116, 111, 116, 73, 111, 110, 67, 117, 114, 114, 101, 110, 116};
    //
    private static byte[] NAME_precision = {112, 114, 101, 99, 105, 115, 105, 111, 110};
    //
    private static byte[] NAME_compressionType = {99, 111, 109, 112, 114, 101, 115, 115, 105, 111, 110, 84, 121, 112, 101};
    //
    private static byte[] NAME_byteOrder = {98, 121, 116, 101, 79, 114, 100, 101, 114};
    //
    private static byte[] NAME_pairOrder = {112, 97, 105, 114, 79, 114, 100, 101, 114};
    //
    private static byte[] NAME_peaks = {112, 101, 97, 107, 115};
    //
    private static byte[] NAME_precursorIntensity = {112, 114, 101, 99, 117, 114, 115, 111, 114, 73, 110, 116, 101, 110, 115, 105, 116, 121};
    //
    private static byte[] NAME_precursorMz = {112, 114, 101, 99, 117, 114, 115, 111, 114, 77, 122};
    //
    private static byte[] NAME_precursorCharge = {112, 114, 101, 99, 117, 114, 115, 111, 114, 67, 104, 97, 114, 103, 101};
    //
    private static byte[] NAME_activationMethod = {97, 99, 116, 105, 118, 97, 116, 105, 111, 110, 77, 101, 116, 104, 111, 100};
    //
    private static byte[] NAME_startMz = {115, 116, 97, 114, 116, 77, 122};
    //
    private static byte[] NAME_endMz = {101, 110, 100, 77, 122};


    //
    public ScanPaser(byte[] aSource)
    {
        _source = aSource;
        //GC.Collect(2);
    }

    //
    private int PositionSeeker(byte[] aTarget)
    {

        for (int i = 0; i < _source.length; i++)
        {
            if (_source[i] == aTarget[0] && (i + aTarget.length) <= _source.length)
            {
                boolean Match = true;
                for (int j = 1; j < aTarget.length; j++)
                {
                    if (_source[i + j] != aTarget[j])
                    {
                        Match = false;
                        break;
                    }
                }
                if (Match == true)
                {
                    return i;
                }
            }
        }
        return -1;
    }

    private String GetValue(int aPosition)
    {
        try
        {
            if (aPosition != -1)
            {
                StringBuilder sb = new StringBuilder();  // 要改
                boolean IsEnd = false, IsStart = false;
                int Position = aPosition;
                do
                {
                    if (_source[Position] == 61) // =
                    {
                        if (_source[Position + 1] == 34) // "
                        {
                            Position = Position + 2;
                            IsStart = true;
                        }
                    }
                    if (IsStart)
                    {
                        sb.append((char)_source[Position]);  //sb.Append(Convert.ToChar(_source[Position]));
                        if (_source[Position + 1] == 34) //"
                        {
                            IsEnd = true;
                        }
                    }

                    Position++;


                } while (IsEnd != true);

                return sb.toString();
            }
            else
            {
                return "";
            }
        }
        catch (java.lang.Exception e)
        {
            return "";
        }

    }
    private String GetContent(int aPosition)
    {
        if (aPosition != -1)
        {
            StringBuilder sb = new StringBuilder();  // 要改
            boolean IsEnd = false, IsStart = false;
            int Position = aPosition;
            do
            {
                if (_source[Position] == 62) // >
                {
                    if (_source[Position + 1] == 60)
                    {
                        return "";
                    }
                    IsStart = true;
                    Position++;
                }
                if (IsStart)
                {
                    sb.append((char)_source[Position]);   //sb.Append(Convert.ToChar(_source[Position]));
                    if (_source[Position + 1] == 60) // <
                    {
                        IsEnd = true;
                    }
                }

                Position++;

            } while (IsEnd != true);

            return sb.toString();
        }
        else
        {
            return "";
        }

    }
    public final String getPrecursorIntensity()
    {
        return GetValue(PositionSeeker(NAME_precursorIntensity));
    }
    public final String getPrecursorMZ()
    {
        return GetContent(PositionSeeker(NAME_precursorMz));
    }
    public final String getActivationMethod()
    {
        return GetValue(PositionSeeker(NAME_activationMethod));
    }
    public final String getPrecursorCharge()
    {
        return GetValue(PositionSeeker(NAME_precursorCharge));
    }
    public final String getPeaks()
    {
        return GetContent(PositionSeeker(NAME_precision));
    }
    public final String getCompressionType()
    {
        return GetValue(PositionSeeker(NAME_compressionType));
    }
    public final String getPrecision()
    {
        return GetValue(PositionSeeker(NAME_precision));
    }
    public final String getByteOrder()
    {
        return GetValue(PositionSeeker(NAME_byteOrder));
    }
    public final String getPairOrder()
    {
        return GetValue(PositionSeeker(NAME_pairOrder));
    }
    public final String getNum()
    {
        return GetValue(PositionSeeker(NAME_num));
    }
    public final String getMsLevel()
    {
        return GetValue(PositionSeeker(NAME_msLevel));
    }
    public final String getPeaksCount()
    {
        return GetValue(PositionSeeker(NAME_peaksCount));
    }
    public final String getPolarity()
    {
        return GetValue(PositionSeeker(NAME_polarity));
    }
    public final String getScanType()
    {
        return GetValue(PositionSeeker(NAME_scanType));
    }
    public final String getFilterLine()
    {
        return GetValue(PositionSeeker(NAME_filterLine));
    }
    public final String getRetentionTime()
    {
        return GetValue(PositionSeeker(NAME_retentionTime));
    }
    public final String getLowMz()
    {
        return GetValue(PositionSeeker(NAME_lowMz));
    }
    public final String getHighMz()
    {
        return GetValue(PositionSeeker(NAME_highMz));
    }
    public final String getStartMz()
    {
        return GetValue(PositionSeeker(NAME_startMz));
    }
    public final String getEndMz()
    {
        return GetValue(PositionSeeker(NAME_endMz));
    }
    public final String getBasePeakMz()
    {
        return GetValue(PositionSeeker(NAME_basePeakMz));
    }
    public final String getBasePeakIntensity()
    {
        return GetValue(PositionSeeker(NAME_basePeakIntensity));
    }
    public final String getTotIonCurrent()
    {
        return GetValue(PositionSeeker(NAME_totIonCurrent));
    }

}